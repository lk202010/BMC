from semantic_text_similarity.models import WebBertSimilarity
from semantic_text_similarity.models import ClinicalBertSimilarity
import nltk
import json
from tqdm import tqdm

nltk.download('punkt')
from nltk import sent_tokenize
import heapq


def sort_sentenct(question, context):
    # web_model = WebBertSimilarity(device='cpu', batch_size=10)  # defaults to GPU prediction

    clinical_model = ClinicalBertSimilarity(device='cuda', batch_size=10)  # defaults to GPU prediction

    # web_model.predict([("She won an olympic gold medal","The women is anolympicchampion")])

    ab_sents = sent_tokenize(context, 'english')
    res = []
    for i in ab_sents:
        # re = web_model.predict([(question, i)])
        re = clinical_model.predict([(question, i)])
        res.append(re.tolist()[0])

    # # 获取list中最大（最小）的n个值
    # heapq.nlargest(len(res), res)

    # 获取list中最大几个值的索引的列表
    sort_index = list(map(res.index, heapq.nlargest(len(res), res)))
    new_context = ""
    for i in sort_index:
        new_context += ab_sents[i]
    return new_context

def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


def get_answer(real_answer, new_context):
    new_answer = []
    start = 0
    while start < len(new_context) and start > -1:
        try:
            answer_start = new_context.index(real_answer, start)
            answer_end = answer_start + len(real_answer)
        except:
            break
        new_answer.append({'answer_start': answer_start, 'answer_end': answer_end, 'text': real_answer})
        # answers.append({'start': answer_start,"end":answer_end, 'text': a})
        start = answer_start + 1
    return new_answer


filepath = "/media/sda2/lk/my_model/Selected paras/BERT/CliCR_v2_mask_to_原始/"
dataset = "train1.0.json"
output_file = "/media/sda2/lk/my_model/Selected paras/BERT/data/clinicalbert_sim/"

with open(filepath + dataset, "r") as fin:
    data1 = json.load(fin)
    print()
    count = 0
    data = []
    for da in tqdm(data1["data"]):
        # question = da["question"]
        # answer = da["answers"]["text"]
        # context = da["context"]
        for i in range(len(da)):
            query = da[i]["question"]
            answer = da[i]["answers"][0]["text"]
            context = da[i]["context"]

            new_context = sort_sentenct(query,context)

            context_word = new_context.split()
            context_split_len = [len(x) for x in context_word]

            if len(answer) != 0:
                real_answer = answer
                new_answer = get_answer(real_answer, new_context)
                if len(new_answer) != 0:
                    data.append([{"question": query, "answers": new_answer, "context": new_context}])
                    count += 1
    save = {'data': data, 'version': "clicr_clinical_sim"}

    save_json(save, output_file+dataset)


    print(count)



#train 55599个样本 运行 45:24:15