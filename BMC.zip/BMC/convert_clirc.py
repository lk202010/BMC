import json

dataset_file = "F:\LK\BioMRC_code-master\BIOMRC\clicr\\train1.0.json"
with open(dataset_file) as f:
    dataset = json.load(f)
print()



def remove_entity_marks(txt):
    return txt.replace("BEG__", "").replace("__END", "")


def to_entities(text, ent_marker="@entity"):
    """
    Text includes entities marked as BEG__w1 w2 w3__END. Transform to a single entity @entityw1_w2_w3.
    """
    word_list = []
    inside = False
    for w in text.split():
        w_stripped = w.strip()
        if w_stripped.startswith("BEG__") and w_stripped.endswith("__END"):
            concept = [w_stripped.split("_")[2]]
            word_list.append(ent_marker + "_".join(concept))
            if inside:  # something went wrong, leave as is
                print("Inconsistent markup.")
        elif w_stripped.startswith("BEG__"):
            # print(inside)
            assert not inside
            inside = True
            concept = [w_stripped.split("_", 2)[-1]]
        elif w_stripped.endswith("__END"):
            if not inside: #inside为false时执行
                word_list.append(w_stripped[:-5])
            else: #inside为True时执行
                concept.append(w_stripped.rsplit("_", 2)[0])
                word_list.append(ent_marker + "_".join(concept))
                inside = False
        else:
            if inside:
                concept.append(w_stripped)
            else:
                word_list.append(w_stripped)
        inside = False

    return " ".join(word_list)


def get_start_end(text, w_stripped, start, end):
    start = text.index(w_stripped, start, end)
    end = start + len(w_stripped) + 1
    return start, end


def find_entity(text):
    entities = []
    tmp_end = 0
    tmp_end1 = len(text)
    for w in text.split():
        w_stripped = w.strip()
        if w_stripped.startswith("@entity"):
            w_stripped = w_stripped[7:]
            start, end = get_start_end(text, w_stripped, tmp_end, tmp_end1)
            # start = text.index(w_stripped, tmp_end, len(text)) #list.index(x[, start[, end]])
            # end = start + len(w_stripped) + 1
            tmp_end = end
            entity_ = w_stripped.split("_")
            entity = " ".join(entity_)
            entities.append({"start": start, "end": end, "text": entity})
    return entities


def get_entities(text):
    all_entities = []
    text_list = text.split()
    num = text.count("__END")
    start = 0
    end = len(text)
    for i in range(num):
        start = text.find("BEG__", start, end)
        end = text.find("__END",start,len(text))
        entity = text[start+5:end]
        all_entities.append(entity)
        start = end
        end = len(text)
    all_entities = list(set(all_entities))
    return all_entities





#{"version","data":["id","source","passage":{"text","entities"},"qas":["id","query","answers":[{"start","end","text"}]]}
version = "1.0"
data = []

context_text_question = []

for doc in dataset["data"]:  # input_data->[document, source]
    source = doc["source"]
    answer = []
    qas = []
    # for document in doc["document"]["context"]: # document—>[qas, title, context]
    context_text = doc["document"]["context"].replace("\n\n","\n")

    title = doc["document"]["title"]
    c = title + context_text
    context_entity = c
    c_ = to_entities(c)
    # context_text = remove_entity_marks(context_text)  # 去掉context_text中的 "BEG__"和"__END"


    qas_ = doc["document"]["qas"]
    for q in qas_:
        query = q["query"]
        context_entity += query
    all_entities = get_entities(context_entity)
    for q in qas_:
        answer = q["answers"]
        qas_id = q["id"]
        query = q["query"]
        context_entity += query
        # 对query进行处理得到question_text
        question_text = remove_entity_marks(query)

        # 对answer(list)进行处理得到{start, end, text}
        all_answers = []
        answers = []
        tmp_end = 0
        for ans in answer:  # 重写
            ans_text = ans["text"].replace("\\\\","")
            all_answers.append(ans_text)


        context_text_question.append({"context:":context_text,"question":question_text,"entities_list":all_entities, "answer":all_answers, "id":qas_id})



print()
#
# with open("E:\机器阅读理解论文代码\clicr-master\data\convert_data\\dev1.0.json", "w") as fout:
#     data_json = json.dumps(data_clirc)
#     fout.write(data_json)


with open("F:\LK\BioMRC_code-master\BIOMRC\clicr\\cloze_style_train.json", "w") as fout:
    data_json = json.dumps(context_text_question)
    fout.write(data_json)