import json
from tqdm import tqdm
filepath = "F:\LK\my_model\data_bioread\sort\\"
dataset = "dev1.0.json"


with open(filepath + dataset, "r") as fin:
    data1 = json.load(fin)
    print()
    count = 0
    for da in data1["data"]:
        count += len(da)

    print(count)