import pandas as pd
import numpy as np
from nltk.corpus import stopwords
import nltk
from tqdm import tqdm
nltk.download('stopwords')
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics.pairwise import euclidean_distances


import json




def select_paras(df):
    documents_df = pd.DataFrame(df, columns=['documents'])

    # removing special characters and stop words from the text
    stop_words_l = stopwords.words('english')
    documents_df['documents_cleaned'] = documents_df.documents.apply(lambda x: " ".join(
        re.sub(r'[^a-zA-Z]', ' ', w).lower() for w in x.split() if
        re.sub(r'[^a-zA-Z]', ' ', w).lower() not in stop_words_l))

    tfidfvectoriser = TfidfVectorizer()
    tfidfvectoriser.fit(documents_df.documents_cleaned)
    tfidf_vectors = tfidfvectoriser.transform(documents_df.documents_cleaned)

    pairwise_similarities = np.dot(tfidf_vectors, tfidf_vectors.T).toarray()
    pairwise_differences = euclidean_distances(tfidf_vectors)

    similar_ix_Cosine = most_similar(0, df, pairwise_similarities, 'Cosine Similarity')
    similar_ix_Euclidean = most_similar(0, df, pairwise_differences, 'Euclidean Distance')

    return similar_ix_Cosine.tolist(), similar_ix_Euclidean.tolist()


def most_similar(doc_id,documents_df, similarity_matrix, matrix):
    if matrix == 'Cosine Similarity':
        similar_ix = np.argsort(similarity_matrix[doc_id])[::-1]
    elif matrix == 'Euclidean Distance':
        similar_ix = np.argsort(similarity_matrix[doc_id])
    return similar_ix


def remove_entity_marks(txt):
    return txt.replace("BEG__", "").replace("__END", "").replace("\n\n"," ").replace("\n"," ")


def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


def get_answer(real_answer, new_context):
    new_answer = []
    start = 0
    while start < len(new_context) and start > -1:
        try:
            answer_start = new_context.index(real_answer, start)
            answer_end = answer_start + len(real_answer)
        except:
            break
        new_answer.append({'answer_start': answer_start, 'answer_end': answer_end, 'text': real_answer})
        # answers.append({'start': answer_start,"end":answer_end, 'text': a})
        start = answer_start + 1
    return new_answer



def convert(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as fi:
        data_ = fi.readlines()
        data_.insert(0, "==============================\n")
        data_[-1] = "=============================="
        context, query, answer = [],[],[]
        # data_ = data_[20746800:]
        for i,line in enumerate(tqdm(data_)):
            answer_ = ''
            if line == "==============================\n":
                context_ = data_[i+1].split("\n")[0]
                query_ = data_[i+3].split("\n")[0].replace("XXXXXX", "[MASK]")
            if line == "------------------------------\n" and (data_[i+2] == "==============================\n" or data_[i+2] == "=============================="):
                answer_ = data_[i+1].split(":")[0]
            if answer_ != '':
                context.append(context_)
                query.append(query_)
                answer.append(answer_)

        count = 0
        data = []
        for con, qa, an in tqdm(zip(context[:50000], query[:50000], answer[:50000]), total=len(context[:50000])):
            b = con.split(". ")
            b.insert(0, qa)
            similar_ix_Cosine, similar_ix_Euclidean = select_paras(b)
            # top_k_paras = []
            # for ix in similar_ix_Cosine[1:]:
            #     z = ix
            #     top_k_paras.append(b[ix])

            new_context = " ".join(b[ix]+" ." for ix in similar_ix_Cosine[1:])
            new_context = new_context.lstrip()


            context_word = new_context.split()
            new_context = " ".join(word for word in context_word)
            new_context = new_context.lstrip()
            context_split_len = [len(x) for x in context_word]
            ans = an
            answers = []
            start = 0
            while start < len(context_word) and start > -1:
                try:
                    s_index = context_word.index(ans, start)
                    answer_start = sum(context_split_len[:s_index]) + 1*s_index
                    answer_end = answer_start + len(ans)
                except:
                    break
                answers.append({'answer_start': answer_start,"answer_end":answer_end, 'text': ans})
                start = answer_start+1
            if len(answers) != 0:
                data.append([{"question":qa, "answers":answers, "context":new_context}])
                count += 1
            if len(answers) == 0:
                print(new_context)
                print(ans)
        save = {'data': data, 'version': "Bioread_SQuAD"}

        save_json(save, output_file)
        print(count)

input_file = "/media/sda2/lk/my_model/data_bioread/bioread_dataset/train_part_0.txt"
output_file = "/media/sda2/lk/my_model/demo_bioread/cos_sort/cs_data/train1.0.json"
convert(input_file, output_file)

input_file = "/media/sda2/lk/my_model/data_bioread/bioread_dataset/valid_part_0.txt"
output_file = "/media/sda2/lk/my_model/demo_bioread/cos_sort/cs_data/dev1.0.json"
convert(input_file, output_file)

input_file = "/media/sda2/lk/my_model/data_bioread/bioread_dataset/test_part_0.txt"
output_file = "/media/sda2/lk/my_model/demo_bioread/cos_sort/cs_data/test1.0.json"
convert(input_file, output_file)