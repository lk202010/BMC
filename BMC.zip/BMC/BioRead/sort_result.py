import json
import torch
from torch.utils.data import DataLoader
import time
from tqdm import tqdm


def get_data(path):
    with open(path, 'rb') as f:
        bioread_dict = json.load(f)["data"]

    texts,queries, answers = [], [], []

    for data in tqdm(bioread_dict):
        for sample in data:
            texts.append(sample["context"])
            queries.append(sample["question"])
            answers.append(sample["answers"][0])

    return texts, queries, answers






from transformers import AutoTokenizer,AdamW,BertForQuestionAnswering
tokenizer = AutoTokenizer.from_pretrained("F:\LK\BioMRC_code-master\\biobert_v1.1_pubmed")



def add_token_positions(encodings, answers):
    start_positions = []
    end_positions = []

    count = 0
    count1 = 0

    for i in range(len(answers)):
        start_positions.append(encodings.char_to_token(i, answers[i]['answer_start']))
        end_positions.append(encodings.char_to_token(i, answers[i]['answer_end']))

        answers_token = tokenizer(answers[i]["text"])
        a = len(answers_token["input_ids"])
        answers_token_len = a - 2

        # if start position is None, the answer passage has been truncated
        if start_positions[-1] is None:
            # start_positions[-1] = tokenizer.model_max_length
            count1 += 1
            start_positions[-1] = 512
            end_positions[-1] = 512

        # if end position is None, the 'char_to_token' function points to the space after the correct token, so add - 1
        if end_positions[-1] is None:
            if start_positions[-1] == 512:
                end_positions[-1] = 512
            else:
                end_positions[-1] = start_positions[-1] + answers_token_len
                # end_positions[-1] = encodings.char_to_token(i, answers[i]['answer_end'] - 1)
                # if end position is still None the answer passage has been truncated
                if end_positions[-1] is None:
                    count += 1
                    end_positions[-1] = tokenizer.model_max_length

    print(count, count1)

    # Update the data in dictionary
    encodings.update({'start_positions': start_positions, 'end_positions': end_positions})






class SquadDataset(torch.utils.data.Dataset):
    def __init__(self, encodings):
        self.encodings = encodings

    def __getitem__(self, idx):
        return {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}

    def __len__(self):
        return len(self.encodings.input_ids)






def get_dataloader(i):
    train_texts, train_queries, train_answers = get_data("F:\LK\my_model\data_bioread\\train1.0.json")
    train_texts, train_queries, train_answers = train_texts[i*200000:i*200000+200000], train_queries[i*200000:i*200000+200000], train_answers[i*200000:i*200000+200000]
    # train_texts, train_queries, train_answers = train_texts[i*20:i*20+20], train_queries[i*20:i*20+20], train_answers[i*20:i*20+20]
    dev_texts, dev_queries, dev_answers = get_data("F:\LK\my_model\data_bioread\dev1.0.json")
    dev_texts, dev_queries, dev_answers = dev_texts[i*12500:i*12500+12500], dev_queries[i*12500:i*12500+12500], dev_answers[i*12500:i*12500+12500]
    # dev_texts, dev_queries, dev_answers = dev_texts[i*12:i*12+12], dev_queries[i*12:i*12+12], dev_answers[i*12:i*12+12]
    test_texts, test_queries, test_answers = get_data("F:\LK\my_model\data_bioread\\test1.0.json")
    test_texts, test_queries, test_answers = test_texts[i*12500:i*12500+12500], test_queries[i*12500:i*12500+12500], test_answers[i*12500:i*12500+12500]

    print("############tokenizer############")
    train_encodings = None
    dev_encodings = None
    train_encodings = tokenizer(train_texts, train_queries, max_length=512, truncation=True, padding=True)
    dev_encodings = tokenizer(dev_texts, dev_queries, max_length=512, truncation=True, padding=True)
    test_encodings = tokenizer(test_texts, test_queries, max_length=512, truncation=True, padding=True)


    add_token_positions(train_encodings, train_answers)
    add_token_positions(dev_encodings, dev_answers)
    add_token_positions(test_encodings, test_answers)

    del train_encodings
    del dev_encodings
    del test_encodings

for i in range(4):
    get_dataloader(i)


