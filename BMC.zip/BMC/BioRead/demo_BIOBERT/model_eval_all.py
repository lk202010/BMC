import torch
from transformers import AutoTokenizer,BertTokenizerFast, BertForQuestionAnswering
import json
from tqdm import tqdm
import os
import numpy as np

import random
import numpy as np
import os
import torch

def seed_torch(seed=1029):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = False

seed_torch()


device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
# Define the bert tokenizer
tokenizer = AutoTokenizer.from_pretrained('/media/sda2/lk/BioBERT/biobert_v1.1_pubmed')



def predicts(model, input_file, output_file, dataset):
    model = model
    filepath = input_file
    output_file = output_file
    dataset = dataset
    eval_pred(model, filepath, dataset, output_file)

# input_file = "/media/sda2/lk/my_model/data_clicr/sort_sentence_3844/"
# output_dev_file = '/media/sda2/lk/my_model/model/HasAnsExact/demo_BIOBERT_CliCR/results_epoch20_answer_vert'+model_name+'dev.txt'
# output_test_file = '/media/sda2/lk/my_model/model/HasAnsExact/demo_BIOBERT_CliCR/results_epoch20_answer_vert'+model_name+'test.txt'
# predicts(model, input_file, output_dev_file, dataset="dev1.0.json")
# predicts(model, input_file, output_test_file, dataset="test1.0.json")
# print("++++++++++++++++++++++++++++++++++++++++++++")

def predict_ans_vert(model, context, query):
    # inputs = tokenizer.encode_plus(query, context, max_length=512, truncation=True, return_tensors='pt')
    inputs = tokenizer.encode_plus(context, query, max_length=512, truncation=True, return_tensors='pt')

    input_ids = inputs["input_ids"].to(device)
    token_type_ids = inputs["token_type_ids"].to(device)
    attention_mask = inputs["attention_mask"].to(device)

    outputs = model(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask)
    # outputs = model(**inputs)
    answer_start = torch.argmax(outputs[0])  # get the most likely beginning of answer with the argmax of the score
    answer_end = torch.argmax(outputs[1])

    # print(input_ids.detach().cpu().numpy().tolist()[0])
    context_len = input_ids.detach().cpu().numpy().tolist()[0].index(102) - 1
    max_answer_length = context_len  # 答案的最大长度
    min_answer_length = 1  # 答案的最小长度
    answer_start_np = outputs[0].detach().cpu().numpy()
    answer_end_np = outputs[1].detach().cpu().numpy()
    # print(answer_start_np)
    # print(answer_end_np)
    answer_start_index_sort = np.argsort(answer_start_np)[0][::-1]
    answer_end_index_sort = np.argsort(answer_end_np)[0][::-1]

    # print(answer_start_index_sort)
    # print(answer_end_index_sort)
    def answer_vert(answer_start_index_sort, answer_end_index_sort, context_len, max_answer_length, min_answer_length):
        for start in answer_start_index_sort:
            if start > context_len:
                continue
            for end in answer_end_index_sort:
                length = end - start + 1
                if end <= context_len and length < max_answer_length and length > min_answer_length:
                    return start, end

    start, end = answer_vert(answer_start_index_sort, answer_end_index_sort, context_len, max_answer_length,
                             min_answer_length)

    answer1 = tokenizer.convert_tokens_to_string(
        tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][start:end]))


    answer = tokenizer.convert_tokens_to_string(
        tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][answer_start:answer_end]))


    return answer, answer1


def normalize_text(s):
    """Removing articles and punctuation, and standardizing whitespace are all typical text processing steps."""
    import string, re

    def remove_articles(text):
        regex = re.compile(r"\b(a|an|the)\b", re.UNICODE)
        return re.sub(regex, " ", text)

    def white_space_fix(text):
        return " ".join(text.split())

    def remove_punc(text):
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def lower(text):
        return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def compute_exact_match(prediction, truth):
    return int(normalize_text(prediction) == normalize_text(truth))
    # return int(prediction == truth)


def compute_f1(prediction, truth):
    pred_tokens = normalize_text(prediction).split()
    truth_tokens = normalize_text(truth).split()

    # if either the prediction or the truth is no-answer then f1 = 1 if they agree, 0 otherwise
    if len(pred_tokens) == 0 or len(truth_tokens) == 0:
        return int(pred_tokens == truth_tokens)

    common_tokens = set(pred_tokens) & set(truth_tokens)

    # if there are no common tokens then f1 = 0
    if len(common_tokens) == 0:
        return 0

    prec = len(common_tokens) / len(pred_tokens)
    rec = len(common_tokens) / len(truth_tokens)

    return 2 * (prec * rec) / (prec + rec)


def give_an_answer(model, context,query,answer):

  # prediction = predict(model, context,query)
  prediction, prediction_ans = predict_ans_vert(model, context,query)
  em_score = compute_exact_match(prediction, answer)
  f1_score = compute_f1(prediction, answer)

  em_score_ans = compute_exact_match(prediction_ans, answer)
  f1_score_ans = compute_f1(prediction_ans, answer)

  return em_score, f1_score, prediction,em_score_ans,f1_score_ans, prediction_ans




def eval_pred(model, filepath, dataset, out_put_file):
    with open(filepath + dataset, "r") as fin:
        data = json.load(fin)

    texts,queries, answers = [], [], []

    for data in tqdm(data["data"]):
        for sample in data:
            texts.append(sample["context"])
            queries.append(sample["question"])
            answers.append(sample["answers"][0]["text"])

    count = 0
    em, f1 = 0, 0
    em_ans, f1_ans = 0, 0
    towrite = []
    for q, a, c in tqdm(zip(queries, answers, texts), total=len(queries)):
        count += 1
        em_, f1_, prediction, em_ans_, f1_ans_, prediction_ans = give_an_answer(model, c, q, a)
        # print(prediction ," : ", a)
        em += em_
        f1 += f1_
        em_ans += em_ans_
        f1_ans += f1_ans_
        towrite.append('{}::{}::{}\n'.format(prediction, prediction_ans, a))

    total_em = em/count
    total_f1 = f1/count
    total_em_ans = em_ans/count
    total_f1_ans = f1_ans/count
    print(em, f1, em_ans, f1_ans, count)
    print("EM:",round(total_em*100, 2))
    print("F1:",round(total_f1*100, 2))
    print("++++++++++++++answers vert++++++++++++++")
    print("EM:",round(total_em_ans*100, 2))
    print("F1:",round(total_f1_ans*100, 2))

    out_file = out_put_file.split(".txt")[0] + '_' + str(total_em*100)[:7] + '_' + str(total_f1*100)[:7] + '_ans_vert_' + str(total_em_ans*100)[:7] + '_' + str(total_f1_ans*100)[:7] + ".txt"

    with open(out_file, 'w' , encoding="utf-8") as f:
        f.write(''.join(towrite))
        f.close()
        print("successful write!")


path = r"/media/sda2/lk/my_model/demo_bioread/cos_sort/demo_BIOBERT/model"
model_name_list = os.listdir(path)
for model_name in model_name_list:
    model_name_path = path+"/"+model_name
    print(model_name)
    model = BertForQuestionAnswering.from_pretrained('/media/sda2/lk/BioBERT/biobert_v1.1_pubmed').to(device)
    model.load_state_dict(torch.load(model_name_path))

    model.eval()

    input_file = "/media/sda2/lk/my_model/data_bioread/"
    output_dev_file = '/media/sda2/lk/my_model/demo_bioread/cos_sort/demo_BIOBERT/results/' + model_name + 'dev.txt'
    output_test_file = '/media/sda2/lk/my_model/demo_bioread/cos_sort/demo_BIOBERT/results/' + model_name + 'test.txt'
    predicts(model, input_file, output_dev_file, dataset="dev1.0.json")
    predicts(model, input_file, output_test_file, dataset="test1.0.json")
    print("++++++++++++++++++++++++++++++++++++++++++++")

