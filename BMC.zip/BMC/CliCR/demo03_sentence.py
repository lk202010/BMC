import json
import numpy as np
import random
import torch
import nltk
nltk.download("punkt")
from nltk import sent_tokenize
from torch.utils.data import DataLoader, Dataset
from transformers import BertTokenizer, BertForQuestionAnswering, AdamW
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

from record_eval import evaluate

device = "cuda" if torch.cuda.is_available() else "cpu"


# Fix random seed for reproducibility
def same_seeds(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


same_seeds(0)

fp16_training = False

model = BertForQuestionAnswering.from_pretrained("F:\LK\BioMRC_code-master\\biobert-large-cased-v1.1").to(device)
tokenizer = BertTokenizer.from_pretrained("F:\LK\BioMRC_code-master\\biobert-large-cased-v1.1")

import json
import numpy as np


def remove_entity_marks(txt):
    return txt.replace("BEG__", "").replace("__END", "").replace("\n", " ").replace("\\", " ").replace("\n"," ").replace("\n\n", " ")


def data_handle(filename, file_type):
    with open(filename, 'r') as fin:
        dataset = json.load(fin)

    # {"version","data":["id","source","passage":{"text","entities"},"qas":["id","query","answers":[{"start","end","text"}]]}
    version = dataset["version"]

    for doc in dataset["data"]:  # input_data->[document, source]
        context_text = doc["document"]["context"]
        title = doc["document"]["title"]
        c = title + " " + context_text
        doc["document"]["context"] = remove_entity_marks(c)  # 去掉context_text中的 "BEG__"和"__END"
        context_text = remove_entity_marks(context_text)

        qas_ = doc["document"]["qas"]
        i = 0
        for q in qas_:
            answer = q["answers"]
            query = q["query"]
            # 对query进行处理得到question_text
            q["query"] = remove_entity_marks(query)

            # 对answer(list)进行处理得到{start, end, text}
            all_answers = []
            answers_positon = []
            tmp_end = 0
            for ans in answer:  # 重写
                ans_text = ans["text"]
                all_answers.append(ans_text)
                # 只找到答案出现的第一个位置
                start = context_text.find(ans_text, tmp_end, len(context_text))
                if start != -1:
                    end = start + len(ans_text) + 1
                    tmp_end = end
                    answers_positon.append({"start": start, "end": end, "text": ans_text})
            doc["document"]["qas"][i]["answers_position"] = answers_positon
            doc["document"]["qas"][i]["all_answer"] = all_answers
            i += 1
    return dataset


# train_data = data_handle("/content/drive/MyDrive/model_demo/data_clirc/train1.0.json", file_type="train")["data"]
dev_data = data_handle("F:\LK\my_model\data_clicr\\dev1.0.json", file_type="dev")["data"]


# test_data = data_handle("/content/drive/MyDrive/model_demo/data_clirc/test1.0.json", file_type="test")["data"]

def QA_Dataset(split, answer, tokenized_questions, tokenized_paragraphs):
    split = split
    answer = answer
    tokenized_questions = tokenized_questions["input_ids"]
    tokenized_paragraphs = tokenized_paragraphs["input_ids"]
    max_question_len = 50
    max_paragraph_len = 300

    ##### TODO: Change value of doc_stride #####
    doc_stride = 200
    # Input sequence length = [CLS] + question + [SEP] + paragraph + [SEP]
    max_seq_len = 1 + max_question_len + 1 + max_paragraph_len + 1
    tokenized_question = tokenized_questions
    # print(tokenized_question)
    tokenized_paragraph = tokenized_paragraphs
    # print(tokenized_paragraph)

    ##### TODO: Preprocessing #####
    # Hint: How to prevent model from learning something it should not learn

    input_ids_list, token_type_ids_list, attention_mask_list, position_list = [], [], [], []
    input_ids_question = [101] + tokenized_question[:max_question_len] + [102]
    qestion_token_len = len(input_ids_question)
    for i in range(0, len(tokenized_paragraph), doc_stride):
        input_ids_paragraph = tokenized_paragraph[i: i + max_paragraph_len] + [102]
        answer_token = tokenizer(answer, add_special_tokens=False)

        start = end = 0
        for j in range(len(input_ids_paragraph)):
            if answer_token["input_ids"][0] == input_ids_paragraph[j]:
                begin = j
                end = j + len(answer_token["input_ids"])
                temp = input_ids_paragraph[begin:end]
                if temp == answer_token["input_ids"]:
                    start = j
                    end = j + len(answer_token["input_ids"])
                    break

        input_ids, token_type_ids, attention_mask = padding(input_ids_question, input_ids_paragraph, max_seq_len)

        input_ids_list.append(input_ids)
        token_type_ids_list.append(token_type_ids)
        attention_mask_list.append(attention_mask)
        position_list.append([start + qestion_token_len, end + qestion_token_len])

    # Pad sequence and obtain inputs to model
    # input_ids, token_type_ids, attention_mask = self.padding(input_ids_question, input_ids_paragraph)
    return input_ids_list, token_type_ids_list, attention_mask_list, position_list


def padding(input_ids_question, input_ids_paragraph, max_seq_len):
    padding_len = max_seq_len - len(input_ids_question) - len(input_ids_paragraph)
    input_ids = input_ids_question + input_ids_paragraph + [0] * padding_len
    token_type_ids = [0] * len(input_ids_question) + [1] * len(input_ids_paragraph) + [0] * padding_len
    attention_mask = [1] * (len(input_ids_question) + len(input_ids_paragraph)) + [0] * padding_len

    return input_ids, token_type_ids, attention_mask


def tokenizer_data(dataset, split):

    data_input = []
    for data_ in tqdm(dataset):
        train_paragraphs = data_["document"]["context"]
        # train_questions_tokenized = []

        data_example_list = []
        for qas_ in data_["document"]["qas"]:
            all_answer = []
            train_question = qas_["query"].replace("@placeholder", "what")
            answer = qas_["answers"][0]["text"]
            answers_position = qas_["answers_position"]
            all_answer.append(qas_["all_answer"])
            id = qas_["id"]
            # train_questions_tokenized.append(tokenizer(train_question, add_special_tokens=False))
            questions_tokenized = tokenizer(train_question, add_special_tokens=False)["input_ids"]
            answer_token = tokenizer(answer, add_special_tokens=False)["input_ids"]

            train_sentence = sent_tokenize(train_paragraphs, 'english')
            sentences_token = []
            input_sentence_list = []
            for sentence in train_sentence:
                position_list = []
                s_token = tokenizer(sentence, add_special_tokens=False)["input_ids"]  # 不管有多长全部做tokenizer
                start = end = 0
                for j in range(len(s_token)):
                    if answer_token[0] == s_token[j]:
                        begin = j
                        end = j + len(answer_token)
                        temp = s_token[begin:end]
                        if temp == answer_token:
                            start = j
                            end = j + len(answer_token)
                            break
                sentences_token.append(s_token)
                # questions_sentence_tokenized = [101] + questions_tokenized + [102] + s_token + [102]
                input_ids_question = [101] + questions_tokenized + [102]
                input_ids_paragraph = s_token + [102]
                questions_tokenized_len = len(input_ids_question)
                position_list.append([start+questions_tokenized_len, end+questions_tokenized_len])
                input_ids, token_type_ids, attention_mask = padding(input_ids_question, input_ids_paragraph, max_seq_len=128)
                input_sentence_list.append([input_ids, token_type_ids, attention_mask, position_list, all_answer]) # 每个句子的example
            data_example_list.append(input_sentence_list) #每个问题的example

        data_input.append(data_example_list) # 每个text的example
        break


    # return input_ids_dict, token_type_ids_dict, attention_mask_dict, all_answer, position_dict
    return data_input


# input_ids_dict, token_type_ids_dict, attention_mask_dict, all_answers = tokenizer_data(dev_data, split="train")

data_input = tokenizer_data(dev_data, "train")
print()

def get_answer(input_ids_list, outputs):
    prediction = ''
    max_prob = float("-inf")
    # for k in range(len(input_ids_list)):
    for k, output in enumerate(outputs):
        question_len = input_ids_list[k].index(102)
        input_ids = input_ids_list[k][question_len+1:]
        start_prob, start_index = torch.max(output.start_logits.squeeze(0)[question_len+1:], dim=0)
        end_prob, end_index = torch.max(output.end_logits.squeeze(0)[question_len+1:], dim=0)
        prob = start_prob + end_prob
        # print("prob:", prob)
        if prob > max_prob and end_index > start_index:
            max_prob = prob
            prediction = tokenizer.decode(input_ids[start_index: end_index + 1])
            # print("prediction: ",prediction)

    return prediction


def train(data_input):
    num_epoch = 1
    validation = True
    logging_step = 100
    learning_rate = 1e-4
    optimizer = AdamW(model.parameters(), lr=learning_rate)

    # data_input = tokenizer_data(dev_data, "train")

    # if fp16_training:
    #     model, optimizer, train_loader = accelerator.prepare(model, optimizer, train_loader)

    model.train()

    print("Start Training ...")

    for epoch in range(num_epoch):
        step = 1
        train_loss = train_acc = f1 = em = 0
        for data_text in tqdm(data_input):
            for date_example in data_text:
                outputs = []
                input_to_text = []
                all_answer = []
                for data in date_example:
                    all_answer = data[4][0]

                    input_ids, token_type_ids, attention_mask = data[0], data[1], data[2]
                    start_position, end_position = data[3][0]
                    # data = [i.to(device) for i in data]
                    input_ids_ = torch.tensor([input_ids]).to(device)
                    token_type_ids_ = torch.tensor([token_type_ids]).to(device)
                    attention_mask_ = torch.tensor([attention_mask]).to(device)
                    # if start_position != 0 and end_position != 0:

                    start_position_ = torch.tensor([start_position]).to(device)
                    end_position_ = torch.tensor([end_position]).to(device)

                    # print(start_position_, start_position_)
                    # Model inputs: input_ids, token_type_ids, attention_mask, start_positions, end_positions (Note: only "input_ids" is mandatory)
                    # Model outputs: start_logits, end_logits, loss (return when start_positions/end_positions are provided)
                    output = model(input_ids_, token_type_ids_, attention_mask_, start_positions=start_position_,
                                   end_positions=end_position_)

                    outputs.append(output)
                    input_to_text.append(input_ids)

                    # print(output.loss)
                    train_loss += output.loss
                    output.loss.backward()

                    optimizer.step()
                    optimizer.zero_grad()

                    ##### TODO: Apply linear learning rate decay #####
                    optimizer.param_groups[0]["lr"] -= learning_rate / 1684

                step += 1

                predict_answer = get_answer(input_to_text, outputs)
                print("predict_answer:",predict_answer)
                em_, f1_ = evaluate([all_answer], [predict_answer])
                em += em_
                f1 += f1_

                if step % logging_step == 0:
                    print(
                        f"Epoch {epoch + 1} | Step {step} | loss = {train_loss.item() / logging_step:.3f}, f1 = {f1 / logging_step:.3f} , em = {em / logging_step:.3f}")
                    train_loss = em = f1 = 0

train(data_input)