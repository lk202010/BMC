import pandas as pd
import numpy as np
from nltk.corpus import stopwords
import nltk
from tqdm import tqdm
nltk.download('stopwords')
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics.pairwise import euclidean_distances


import json

with open("F:\LK\BioMRC_code-master\clicr\data\\clicr_squad_v2_MASK\\train1.0.json", "r") as fin:
     data = json.load(fin)
     print()


def select_paras(df):
    documents_df = pd.DataFrame(df, columns=['documents'])

    # removing special characters and stop words from the text
    stop_words_l = stopwords.words('english')
    documents_df['documents_cleaned'] = documents_df.documents.apply(lambda x: " ".join(
        re.sub(r'[^a-zA-Z]', ' ', w).lower() for w in x.split() if
        re.sub(r'[^a-zA-Z]', ' ', w).lower() not in stop_words_l))

    tfidfvectoriser = TfidfVectorizer()
    tfidfvectoriser.fit(documents_df.documents_cleaned)
    tfidf_vectors = tfidfvectoriser.transform(documents_df.documents_cleaned)

    pairwise_similarities = np.dot(tfidf_vectors, tfidf_vectors.T).toarray()
    pairwise_differences = euclidean_distances(tfidf_vectors)

    similar_ix_Cosine = most_similar(0, df, pairwise_similarities, 'Cosine Similarity')
    similar_ix_Euclidean = most_similar(0, df, pairwise_differences, 'Euclidean Distance')

    return similar_ix_Cosine.tolist(), similar_ix_Euclidean.tolist()


def most_similar(doc_id,documents_df, similarity_matrix, matrix):
    if matrix == 'Cosine Similarity':
        similar_ix = np.argsort(similarity_matrix[doc_id])[::-1]
    elif matrix == 'Euclidean Distance':
        similar_ix = np.argsort(similarity_matrix[doc_id])
    return similar_ix


def remove_entity_marks(txt):
    return txt.replace("BEG__", "").replace("__END", "").replace("\n\n"," ").replace("\n"," ")


def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


def get_answer(real_answer, new_context):
    new_answer = []
    start = 0
    while start < len(new_context) and start > -1:
        try:
            answer_start = new_context.index(real_answer, start)
            answer_end = answer_start + len(real_answer)
        except:
            break
        new_answer.append({'answer_start': answer_start, 'answer_end': answer_end, 'text': real_answer})
        # answers.append({'start': answer_start,"end":answer_end, 'text': a})
        start = answer_start + 1
    return new_answer


sample = []
no_ans = []
max_len, hasAnsExact, noAns = 0,0,0
count = 0
for data in tqdm(data["data"]):

    a = data["paragraphs"][0]["context"]
    b = remove_entity_marks(a).split(" .")
    qas = []
    qas_no = []
    for qa in data["paragraphs"][0]["qas"]:
        ques = remove_entity_marks(qa["question"])

        b.insert(0, ques)
        similar_ix_Cosine, similar_ix_Euclidean = select_paras(b)

        top_k_paras = []
        for ix in similar_ix_Cosine[1:]:
            top_k_paras.append(b[ix])

        new_context = "".join(p for p in top_k_paras)
        new_context = new_context.lstrip()

        if len(new_context) > max_len:
            max_len = len(new_context)


        if len(qa["answers"]) != 0:
            count += 1
            real_answer = qa["answers"][0]["text"]
            new_answer = get_answer(real_answer, new_context)

            if len(new_answer) != 0:
                qas.append({"question": ques, "id": qa["id"], "answers": new_answer, "context": new_context, "is_impossible" : qa["is_impossible"]})
                hasAnsExact += 1
        # else:
        #     emtpy = []
        #     emtpy.append({'answer_start': 0, 'answer_end': 0, 'text': ""})
        #     qas.append({"question": ques, "id": qa["id"], "answers": emtpy, "context": new_context, "is_impossible" : qa["is_impossible"]})
        #     noAns += 1

        b.pop(0)

    sample.append(qas)

save = {'data': sample, 'version': "Sort_sentence_all"}
# save2 = {'data': no_ans, 'version': "select_paras_Top_4_no_question_NoAns"}

save_json(save, "F:\LK\my_model\data_clicr\sort_all\\train11.0.json")


print(hasAnsExact+noAns)
print(count)

"""将与问题计算相似度的句子排序后，组成新的文本
train 55599
dev 3844
test 4259
"""