import json
filepath = "F:\LK\my_model\data_clicr\sort_all\model2\\"
dataset = "all_all_epoch1_dev_55.20_58.78.txt"

with open(filepath+dataset, "r", encoding="utf-8") as fin:
    data_ = fin.readlines()
    all_count, has_ans, no_ans = 0,0,0
    for data in data_:
        pred = data.split("::")[0]
        answer = data.split("::")[1].replace("\n","")
        if pred == answer:
            all_count += 1
        if pred == "" and answer == "":
            no_ans += 1
        if pred != "" and pred == answer:
            has_ans += 1
print(all_count, has_ans, no_ans)

# all_all_epoch1_dev_56.95_59.98.txt : 3636 1522 2114
# all_all_epoch1_dev_55.20_58.78.txt : 3525 1534 1991
