import json
import numpy as np
import random
import torch
from torch.utils.data import DataLoader, Dataset
from transformers import BertTokenizer, BertForQuestionAnswering, AdamW
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
from record_eval import evaluate

device = "cuda" if torch.cuda.is_available() else "cpu"


# Fix random seed for reproducibility
def same_seeds(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
same_seeds(0)


fp16_training = False


model = BertForQuestionAnswering.from_pretrained("F:\\LK\RCM-Question-Answering-master\\bert-base-uncased").to(device)
tokenizer = BertTokenizer.from_pretrained("F:\\LK\\RCM-Question-Answering-master\\bert-base-uncased")

import json
import numpy as np

def remove_entity_marks(txt):
    return txt.replace("BEG__", "").replace("__END", "").replace("\n"," ").replace("\\"," ").replace("\n", " ").replace("\n\n", " ")

def data_handle(filename, file_type):
    with open(filename, 'r') as fin:
        dataset = json.load(fin)

    #{"version","data":["id","source","passage":{"text","entities"},"qas":["id","query","answers":[{"start","end","text"}]]}
    version = dataset["version"]

    for doc in dataset["data"]:  # input_data->[document, source]
        context_text = doc["document"]["context"]
        title = doc["document"]["title"]
        c = title + " " + context_text
        doc["document"]["context"] = remove_entity_marks(c)  # 去掉context_text中的 "BEG__"和"__END"
        context_text = remove_entity_marks(context_text)

        qas_ = doc["document"]["qas"]
        i = 0
        for q in qas_:
            answer = q["answers"]
            query = q["query"]
            # 对query进行处理得到question_text
            q["query"] = remove_entity_marks(query)

            # 对answer(list)进行处理得到{start, end, text}
            all_answers = []
            answers_positon = []
            tmp_end = 0
            for ans in answer:  # 重写
                ans_text = ans["text"]
                all_answers.append(ans_text)
                # 只找到答案出现的第一个位置
                start = context_text.find(ans_text, tmp_end, len(context_text))
                if start != -1:
                    end = start + len(ans_text) + 1
                    tmp_end = end
                    answers_positon.append({"start": start, "end": end, "text": ans_text})
            doc["document"]["qas"][i]["answers_position"] = answers_positon
            doc["document"]["qas"][i]["all_answer"] = all_answers
            i+=1
    return dataset

# train_data = data_handle("/content/drive/MyDrive/model_demo/data_clirc/train1.0.json", file_type="train")["data"]
dev_data = data_handle("F:\LK\my_model\data_clicr\\dev1.0.json", file_type="dev")["data"]
# test_data = data_handle("/content/drive/MyDrive/model_demo/data_clirc/test1.0.json", file_type="test")["data"]


# class QA_Dataset(Dataset):
#     def __init__(self, split, questions, tokenized_questions, tokenized_paragraphs):
#         self.split = split
#         self.questions = questions
#         self.tokenized_questions = tokenized_questions["input_ids"]
#         self.tokenized_paragraphs = tokenized_paragraphs["input_ids"]
#         self.max_question_len = 50
#         self.max_paragraph_len = 450
#
#         ##### TODO: Change value of doc_stride #####
#         self.doc_stride = 350
#
#         # Input sequence length = [CLS] + question + [SEP] + paragraph + [SEP]
#         self.max_seq_len = 1 + self.max_question_len + 1 + self.max_paragraph_len + 1
#
#     def __len__(self):
#         return len(self.questions)
#
#     def __getitem__(self, idx):
#         # print('run+++++++++++++++')
#         # question = self.questions[0]
#         # print(question)
#         tokenized_question = self.tokenized_questions
#         # print(tokenized_question)
#         tokenized_paragraph = self.tokenized_paragraphs
#
#         # print(tokenized_paragraph)
#
#         ##### TODO: Preprocessing #####
#         # Hint: How to prevent model from learning something it should not learn
#
#         if self.split == "train":
#             input_ids_list, token_type_ids_list, attention_mask_list = [], [], []
#             input_ids_question = [101] + tokenized_question[:self.max_question_len] + [102]
#             for i in range(0, len(tokenized_paragraph), self.doc_stride):
#                 input_ids_paragraph = tokenized_paragraph[i: i + self.max_paragraph_len] + [102]
#                 input_ids, token_type_ids, attention_mask = self.padding(input_ids_question, input_ids_paragraph)
#
#                 input_ids_list.append(input_ids)
#                 token_type_ids_list.append(token_type_ids)
#                 attention_mask_list.append(attention_mask)
#
#             # Pad sequence and obtain inputs to model
#             # input_ids, token_type_ids, attention_mask = self.padding(input_ids_question, input_ids_paragraph)
#             return input_ids_list, token_type_ids_list, attention_mask_list
#
#         # Validation/Testing
#         else:
#             input_ids_list, token_type_ids_list, attention_mask_list = [], [], []
#
#             # Paragraph is split into several windows, each with start positions separated by step "doc_stride"
#             for i in range(0, len(tokenized_paragraph), self.doc_stride):
#                 # Slice question/paragraph and add special tokens (101: CLS, 102: SEP)
#                 input_ids_question = [101] + tokenized_question[:self.max_question_len] + [102]
#                 input_ids_paragraph = tokenized_paragraph[i: i + self.max_paragraph_len] + [102]
#
#                 # Pad sequence and obtain inputs to model
#                 input_ids, token_type_ids, attention_mask = self.padding(input_ids_question, input_ids_paragraph)
#
#                 input_ids_list.append(input_ids)
#                 token_type_ids_list.append(token_type_ids)
#                 attention_mask_list.append(attention_mask)
#
#             return input_ids_list, token_type_ids_list, attention_mask_list
#
#     def padding(self, input_ids_question, input_ids_paragraph):
#         # Pad zeros if sequence length is shorter than max_seq_len
#         padding_len = self.max_seq_len - len(input_ids_question) - len(input_ids_paragraph)
#         # Indices of input sequence tokens in the vocabulary
#         input_ids = input_ids_question + input_ids_paragraph + [0] * padding_len
#         # Segment token indices to indicate first and second portions of the inputs. Indices are selected in [0, 1]
#         token_type_ids = [0] * len(input_ids_question) + [1] * len(input_ids_paragraph) + [0] * padding_len
#         # Mask to avoid performing attention on padding token indices. Mask values selected in [0, 1]
#         attention_mask = [1] * (len(input_ids_question) + len(input_ids_paragraph)) + [0] * padding_len
#
#         return input_ids, token_type_ids, attention_mask

def QA_Dataset(split, answer, tokenized_questions, tokenized_paragraphs):
    split = split
    answer = answer
    tokenized_questions = tokenized_questions["input_ids"]
    tokenized_paragraphs = tokenized_paragraphs["input_ids"]
    max_question_len = 50
    max_paragraph_len = 300

    ##### TODO: Change value of doc_stride #####
    doc_stride = 200
    # Input sequence length = [CLS] + question + [SEP] + paragraph + [SEP]
    max_seq_len = 1 + max_question_len + 1 + max_paragraph_len + 1
    tokenized_question = tokenized_questions
    # print(tokenized_question)
    tokenized_paragraph = tokenized_paragraphs
    # print(tokenized_paragraph)

    ##### TODO: Preprocessing #####
    # Hint: How to prevent model from learning something it should not learn

    input_ids_list, token_type_ids_list, attention_mask_list, position_list = [], [], [], []
    input_ids_question = [101] + tokenized_question[:max_question_len] + [102]
    question_token_len = len(input_ids_question)
    for i in range(0, len(tokenized_paragraph), doc_stride):
        input_ids_paragraph = tokenized_paragraph[i: i + max_paragraph_len] + [102]
        answer_token = tokenizer(answer, add_special_tokens=False)

        start = end = 0
        for j in range(len(input_ids_paragraph)):
            if answer_token["input_ids"][0] == input_ids_paragraph[j]:
                begin = j
                end = j+len(answer_token["input_ids"])
                temp = input_ids_paragraph[begin:end]
                if temp == answer_token["input_ids"]:
                    start = j
                    end = j+len(answer_token["input_ids"])
                    break

        input_ids, token_type_ids, attention_mask = padding(input_ids_question, input_ids_paragraph,max_seq_len)

        input_ids_list.append(input_ids)
        token_type_ids_list.append(token_type_ids)
        attention_mask_list.append(attention_mask)
        position_list.append([start+question_token_len,end+question_token_len])

    # Pad sequence and obtain inputs to model
    # input_ids, token_type_ids, attention_mask = self.padding(input_ids_question, input_ids_paragraph)
    return input_ids_list, token_type_ids_list, attention_mask_list, position_list



def padding(input_ids_question, input_ids_paragraph, max_seq_len):
    # Pad zeros if sequence length is shorter than max_seq_len
    padding_len = max_seq_len - len(input_ids_question) - len(input_ids_paragraph)
    # Indices of input sequence tokens in the vocabulary
    input_ids = input_ids_question + input_ids_paragraph + [0] * padding_len
    # Segment token indices to indicate first and second portions of the inputs. Indices are selected in [0, 1]
    token_type_ids = [0] * len(input_ids_question) + [1] * len(input_ids_paragraph) + [0] * padding_len
    # Mask to avoid performing attention on padding token indices. Mask values selected in [0, 1]
    attention_mask = [1] * (len(input_ids_question) + len(input_ids_paragraph)) + [0] * padding_len

    return input_ids, token_type_ids, attention_mask



def tokenizer_data(dataset, split):
    input_ids_dict, token_type_ids_dict, attention_mask_dict, position_dict = {}, {}, {},{}
    all_answer = []
    for data_ in dataset:
        train_paragraphs = data_["document"]["context"]
        train_paragraphs_tokenized = tokenizer(train_paragraphs, add_special_tokens=False)  # 不管有多长全部做tokenizer

        # train_questions_tokenized = []

        for qas_ in data_["document"]["qas"]:
            train_question = qas_["query"]
            answer = qas_["answers"][0]["text"]
            answers_position = qas_["answers_position"]
            all_answer.append(qas_["all_answer"])
            id = qas_["id"]
            # train_questions_tokenized.append(tokenizer(train_question, add_special_tokens=False))
            train_questions_tokenized = tokenizer(train_question, add_special_tokens=False)

            # print("answers_position:", answers_position)
            # print("train_questions_tokenized:", train_questions_tokenized)
            # print("train_paragraphs_tokenized:", train_paragraphs_tokenized)
            input_ids, token_type_ids, attention_mask, positopn = QA_Dataset(split, answer, train_questions_tokenized,
                                                                   train_paragraphs_tokenized)
            input_ids_dict[id] = input_ids
            token_type_ids_dict[id] = token_type_ids
            attention_mask_dict[id] = attention_mask
            position_dict[id] = positopn
    return input_ids_dict, token_type_ids_dict, attention_mask_dict, all_answer, position_dict

# input_ids_dict, token_type_ids_dict, attention_mask_dict, all_answers = tokenizer_data(dev_data, split="train")

print()


def get_answer(input_ids_list, outputs):
    prediction = ''
    max_prob = float("-inf")
    # for k in range(len(input_ids_list)):
    for k, output in enumerate(outputs):
        start_prob, start_index = torch.max(output.start_logits.squeeze(0), dim=0)
        end_prob, end_index = torch.max(output.end_logits.squeeze(0), dim=0)

        prob = start_prob + end_prob
        if prob > max_prob and end_index > start_index:
            max_prob = prob
            prediction = tokenizer.decode(input_ids_list[k][start_index: end_index + 1])

    return prediction



def train(dataset):
    num_epoch = 1
    validation = True
    logging_step = 100
    learning_rate = 1e-4
    optimizer = AdamW(model.parameters(), lr=learning_rate)

    input_ids_dict, token_type_ids_dict, attention_mask_dict, all_answers, position_dict = tokenizer_data(dataset, split="train")

    # if fp16_training:
    #     model, optimizer, train_loader = accelerator.prepare(model, optimizer, train_loader)

    model.train()

    print("Start Training ...")

    for epoch in range(num_epoch):
        step = 1
        train_loss = train_acc = f1 = em = 0
        for i in range(len(input_ids_dict)):
            input_ids_list, token_type_ids_list, attention_mask_list,position_list = list(input_ids_dict.values())[i], list(token_type_ids_dict.values())[i], list(attention_mask_dict.values())[i],list(position_dict.values())[i]
            all_answer = all_answers[i]

            outputs = []
            input_to_text = []
            for data in tqdm(zip(input_ids_list, token_type_ids_list, attention_mask_list, position_list)):
                # Load all data into GPU
                input_ids, token_type_ids, attention_mask = data[0], data[1], data[2]
                start_position, end_position = data[3]
                # data = [i.to(device) for i in data]
                input_ids_ = torch.tensor([input_ids]).to(device)
                token_type_ids_ = torch.tensor([token_type_ids]).to(device)
                attention_mask_ = torch.tensor([attention_mask]).to(device)
                if start_position != None:
                    start_position_ = torch.tensor([start_position]).to(device)
                    end_position_ = torch.tensor([end_position]).to(device)

                    # Model inputs: input_ids, token_type_ids, attention_mask, start_positions, end_positions (Note: only "input_ids" is mandatory)
                    # Model outputs: start_logits, end_logits, loss (return when start_positions/end_positions are provided)
                    output = model(input_ids_, token_type_ids_, attention_mask_, start_position_, end_position_)
                    outputs.append(output)
                    input_to_text.append(input_ids)

                    # # Choose the most probable start position / end position
                    # start_index = torch.argmax(output.start_logits, dim=1)
                    # end_index = torch.argmax(output.end_logits, dim=1)
                    #
                    #
                    # predict_id = input_ids[start_index: end_index+1]
                    # predict_answer = tokenizer.decode(predict_id)
                    # em_, f1_ = evaluate([all_answer], predict_answer)
                    # em += em_
                    # f1 += f1_

                    # Prediction is correct only if both start_index and end_index are correct
                    # train_acc += ((start_index == data[3]) & (end_index == data[4])).float().mean()
                    if output.loss:
                        train_loss += output.loss
                        output.loss.backward()

                        optimizer.step()
                        optimizer.zero_grad()
                        step += 1

                        ##### TODO: Apply linear learning rate decay #####
                        optimizer.param_groups[0]["lr"] -= learning_rate / 1684


            predict_answer = get_answer(input_to_text, outputs)
            em_, f1_ = evaluate([all_answer], predict_answer)
            em += em_
            f1 += f1_

            if step % logging_step == 0:
                print(
                    f"Epoch {epoch + 1} | Step {step} | loss = {train_loss.item() / logging_step:.3f}, f1 = {f1 / logging_step:.3f} , em = {em / logging_step:.3f}")
                train_loss = em = f1 = 0

            # if validation:
            #     print("Evaluating Dev Set ...")
            #     model.eval()
            #     with torch.no_grad():
            #         dev_acc = 0
            #         for i, data in enumerate(tqdm(dev_loader)):
            #             output = model(input_ids=data[0].squeeze(dim=0).to(device),
            #                            token_type_ids=data[1].squeeze(dim=0).to(device),
            #                            attention_mask=data[2].squeeze(dim=0).to(device))
            #             # prediction is correct only if answer text exactly matches
            #             dev_acc += evaluate(data, output) == dev_questions[i]["answer_text"]
            #         print(f"Validation | Epoch {epoch + 1} | acc = {dev_acc / len(dev_loader):.3f}")
            #     model.train()

    # Save a model and its configuration file to the directory 「saved_model」
    # i.e. there are two files under the direcory 「saved_model」: 「pytorch_model.bin」 and 「config.json」
    # Saved model can be re-loaded using 「model = BertForQuestionAnswering.from_pretrained("saved_model")」
    # print("Saving Model ...")
    # model_save_dir = "saved_model"
    # model.save_pretrained(model_save_dir)

train(dev_data)