import json
filepath = "F:\LK\my_model\data_clicr\has_impossible_answer_all\\"
dataset = "test1.0.json"

with open(filepath + dataset, "r") as fin:
    data1 = json.load(fin)
    print()
    count = 0
    has_synonym_count, no_synonym_count = 0, 0
    no_answer_count = 0
    for da in data1["data"]:
        count += len(da)
        for qas in da:
            real_answer = qas["answers"][0]["text"]
            synonym_answer_list = qas["all_answers"]
            context = qas["context"]
            if qas["is_impossible"]:
                no_answer_count += 1
                for synonym_answer in synonym_answer_list:
                    if synonym_answer in context:
                        has_synonym_count += 1
                        break

    print(count,no_answer_count)
    print(has_synonym_count)
    print(count - has_synonym_count)

"""
dev noAns的部分，在impossibel_answers中的答案在context中的有584， 不在context的有5807
test noAns的部分，在impossibel_answers中的答案在context中的有617， 不在context的有6567
"""


origin_filepath = "F:\LK\BioMRC_code-master\BIOMRC\clicr\\"
dataset = "cloze_style_dev.json"
entity_list_dict = dict()
with open(origin_filepath + dataset, "r") as fin:
    origin_data = json.load(fin)
    count_an = 0
    count_an1 = 0
    count = 0
    for data in origin_data:
        count += 1
        entity_list_dict[data["id"]] = data["entities_list"]
        for an in data["answer"]:
            if an in data["entities_list"]:
                count_an += 1
                break
        if data["answer"][0] in data["entities_list"]:
            count_an1 += 1
    print("all_count:", count)
    print("count_an:", count_an)
    print("count_an1:", count_an1)