import json

filepath = "F:\LK\my_model\data_clicr\sort_sentence_3844\sort_sentence_hasAnsExact\\"
dataset = "train_all_epoch1_sort_sentence_3844_dev_13.39_48.29.txt"

with open(filepath + dataset, "r", encoding="utf-8") as fin:
    data = fin.readlines()
    print()
    count = 0
    em = 0
    for a in data:
        pred = a.split("::")[0].split(" ")[:-1]
        pred = " ".join(x for x in pred)
        answer = a.split("::")[1].replace("\n","")
        if answer in pred:
            count += 1
        if answer == pred:
            em += 1

print(count)
print(em)