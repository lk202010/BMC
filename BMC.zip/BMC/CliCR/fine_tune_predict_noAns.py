import torch
from transformers import AutoTokenizer,BertTokenizerFast
import json
from tqdm import tqdm

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
# Define the bert tokenizer
tokenizer = AutoTokenizer.from_pretrained('F:\LK\BioMRC_code-master\\biobert_v1.1_pubmed')

# Load the fine-tuned modeol

model = torch.load("F:/LK/my_model/Best_model/model_Euclidean_train_20000_dev_1.pkl",map_location=torch.device('cuda'))
model.eval()


def predict(context, query):
    inputs = tokenizer.encode_plus(context, query, max_length=512, truncation=True, return_tensors='pt')

    input_ids = inputs["input_ids"].to(device)
    token_type_ids = inputs["token_type_ids"].to(device)
    attention_mask = inputs["attention_mask"].to(device)

    outputs = model(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask)
    # outputs = model(**inputs)
    answer_start = torch.argmax(outputs[0])  # get the most likely beginning of answer with the argmax of the score
    answer_end = torch.argmax(outputs[1]) + 1

    answer = tokenizer.convert_tokens_to_string(
        tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][answer_start:answer_end]))

    return answer


def normalize_text(s):
    """Removing articles and punctuation, and standardizing whitespace are all typical text processing steps."""
    import string, re

    def remove_articles(text):
        regex = re.compile(r"\b(a|an|the)\b", re.UNICODE)
        return re.sub(regex, " ", text)

    def white_space_fix(text):
        return " ".join(text.split())

    def remove_punc(text):
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def lower(text):
        return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))


def compute_exact_match(prediction, truth):
    return int(normalize_text(prediction) == normalize_text(truth))


def compute_f1(prediction, truth):
    pred_tokens = normalize_text(prediction).split()
    truth_tokens = normalize_text(truth).split()

    # if either the prediction or the truth is no-answer then f1 = 1 if they agree, 0 otherwise
    if len(pred_tokens) == 0 or len(truth_tokens) == 0:
        return int(pred_tokens == truth_tokens)

    common_tokens = set(pred_tokens) & set(truth_tokens)

    # if there are no common tokens then f1 = 0
    if len(common_tokens) == 0:
        return 0

    prec = len(common_tokens) / len(pred_tokens)
    rec = len(common_tokens) / len(truth_tokens)

    return 2 * (prec * rec) / (prec + rec)


def give_an_answer(context,query,answer):

  prediction = predict(context,query)
  result = []
  for ans in answer:
      em_score = compute_exact_match(prediction, ans)
      f1_score = compute_f1(prediction, ans)
      result.append([em_score, f1_score, prediction, ans])

  return result




def eval_pred(filepath, dataset, out_put_file):
    with open(filepath + dataset, "r") as fin:
        data = json.load(fin)

    texts,queries, answers = [], [], []

    for data in tqdm(data["data"]):
        for sample in data:
            texts.append(sample["context"])
            queries.append(sample["question"])
            answers.append(sample["impossible_answer"])

    count = 0
    em, f1 = 0, 0
    towrite = []
    for q, a, c in tqdm(zip(queries, answers, texts), total=len(queries)):
        count += 1
        # result = []
        # for ans in a:
        #     em_, f1_, prediction, a_ = give_an_answer(c, q, ans)
        #     result.append([em_, f1_, prediction, a_])
        result = give_an_answer(c, q, a)
        result_ = sorted(result, key=lambda x:(x[0],x[1]), reverse=True)
        result__ = sorted(result_, key=lambda x: (x[1], x[0]), reverse=True)
        # print(prediction ," : ", a)
        em += result__[0][0]
        f1 += result__[0][1]
        towrite.append('{}::{}\n'.format(result__[0][2], result__[0][3]))


    total_em = em/count
    total_f1 = f1/count
    print(em, f1, count)
    print("EM:",total_em)
    print("F1:",total_f1)

    out_file = out_put_file.split(".txt")[0] + '_' + str(total_em*100)[:5] + '_' + str(total_f1*100)[:5] + ".txt"

    with open(out_file, 'w' , encoding="utf-8") as f:
        f.write(''.join(towrite))
        f.close()
        print("successful write!")


"""预测NoAns 没有答案的数据集"""
filepath = "F:\LK\my_model\data_clicr\clicr_squad_Cosine_HasAnsExact_NoAns_3844\\"
dataset = "dev1.0.json"
output_file = 'F:\LK\my_model\data_clicr\clicr_squad_Cosine_NoAns\\Consine_dev.txt'
eval_pred(filepath, dataset,output_file)
print("++++++++++++++++++++++++++++++++++++++++++++")

filepath = "F:\LK\my_model\data_clicr\clicr_squad_Cosine_HasAnsExact_NoAns_3844\\"
dataset = "test1.0.json"
output_file = 'F:\LK\my_model\data_clicr\clicr_squad_Cosine_NoAns\\Consine_test.txt'
eval_pred(filepath, dataset, output_file)
print("++++++++++++++++++++++++++++++++++++++++++++")

# filepath = "F:\LK\BioMRC_code-master\clicr\data\clicr_squad_select_Euclidean_top3\\"
# dataset = "dev1.0.json"
# output_file = 'F:\LK\my_model\TL_Best_model\\model_finetune_on_SQuAD_epoch_1\\Euclidean_dev_result_on_model.txt'
# eval_pred(filepath, dataset, output_file)
# print("++++++++++++++++++++++++++++++++++++++++++++")
#
# filepath = "F:\LK\BioMRC_code-master\clicr\data\clicr_squad_select_Euclidean_top3\\"
# dataset = "test1.0.json"
# output_file = 'F:\LK\my_model\TL_Best_model\\model_finetune_on_SQuAD_epoch_1\\Euclidean_dev_result_on_model.txt'
# eval_pred(filepath, dataset, output_file)
# print("++++++++++++++++++++++++++++++++++++++++++++")


# 将@placeholder换成疑问词
# filepath = "F:\LK\BioMRC_code-master\clicr\data\clicr_squad_what_select_top3\\"
# dataset = "dev1.0.json"
# output_file = 'F:\LK\my_model\Best_model\\licr_squad_what_select_top3\\dev.txt'
# eval_pred(filepath, dataset, output_file)
# print("++++++++++++++++++++++++++++++++++++++++++++")
#
# filepath = "F:\LK\BioMRC_code-master\clicr\data\clicr_squad_what_select_top3\\"
# dataset = "test1.0.json"
# output_file = 'F:\LK\my_model\Best_model\\licr_squad_what_select_top3\\test.txt'
# eval_pred(filepath, dataset, output_file)
# print("++++++++++++++++++++++++++++++++++++++++++++")