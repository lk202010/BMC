import json
from pathlib import Path
import torch
from torch.utils.data import DataLoader
import time
from tqdm import tqdm


def get_data(path):
    with open(path, 'rb') as f:
        clicr_dict = json.load(f)["data"]

    texts,queries, answers = [], [], []

    for data in tqdm(clicr_dict):
        for sample in data:
            texts.append(sample["context"])
            queries.append(sample["question"])
            answers.append(sample["answers"][0])

    return texts, queries, answers

# train_texts, train_queries, train_answers = get_data("F:\LK\BioMRC_code-master\clicr\data\clicr_squad_what_select_consine_top3\\train1.0.json")
# train_texts, train_queries, train_answers = train_texts[:20000], train_queries[:20000], train_answers[:20000]
# dev_texts, dev_queries, dev_answers = get_data("F:\LK\BioMRC_code-master\clicr\data\clicr_squad_what_select_consine_top3\dev1.0.json")
# test_texts, test_queries, test_answers = get_data("F:\LK\BioMRC_code-master\clicr\data\clicr_squad_what_select_consine_top3\\test1.0.json")
# HasAnsExact
train_texts, train_queries, train_answers = get_data("F:\LK\my_model\data_clicr\sort_sentence_3844\\train1.0.json")
train_texts, train_queries, train_answers = train_texts[:20000], train_queries[:20000], train_answers[:20000]
dev_texts, dev_queries, dev_answers = get_data("F:\LK\my_model\data_clicr\sort_sentence_3844\dev1.0.json")
test_texts, test_queries, test_answers = get_data("F:\LK\my_model\data_clicr\sort_sentence_3844\\test1.0.json")

from transformers import AutoTokenizer,AdamW,BertForQuestionAnswering
tokenizer = AutoTokenizer.from_pretrained("F:\LK\BioMRC_code-master\\biobert_v1.1_pubmed")
print("+++++++++++++++++++++")
train_encodings = tokenizer(train_texts, train_queries, max_length=512, truncation=True, padding=True)
print(1)
dev_encodings = tokenizer(dev_texts, dev_queries, max_length=512, truncation=True, padding=True)
print(2)
test_encodings = tokenizer(test_texts, test_queries, max_length=512, truncation=True, padding=True)


print("+++++++++++++++++++++")
def add_token_positions(encodings, answers):
    start_positions = []
    end_positions = []

    count = 0
    count1 = 0

    for i in range(len(answers)):
        start_positions.append(encodings.char_to_token(i, answers[i]['answer_start']))
        end_positions.append(encodings.char_to_token(i, answers[i]['answer_end']))

        answers_token = tokenizer(answers[i]["text"])
        a = len(answers_token["input_ids"])
        answers_token_len = a - 2

        # if start position is None, the answer passage has been truncated
        if start_positions[-1] is None:
            # start_positions[-1] = tokenizer.model_max_length
            count1 += 1
            start_positions[-1] = 512

        # if end position is None, the 'char_to_token' function points to the space after the correct token, so add - 1
        if end_positions[-1] is None:
            if start_positions[-1] == 512:
                end_positions[-1] = 512
            else:
                end_positions[-1] = start_positions[-1] + answers_token_len
                # end_positions[-1] = encodings.char_to_token(i, answers[i]['answer_end'] - 1)
                # if end position is still None the answer passage has been truncated
                if end_positions[-1] is None:
                    count += 1
                    end_positions[-1] = tokenizer.model_max_length

    print(count, count1)

    # Update the data in dictionary
    encodings.update({'start_positions': start_positions, 'end_positions': end_positions})

add_token_positions(train_encodings, train_answers)
add_token_positions(dev_encodings, dev_answers)
add_token_positions(test_encodings, test_answers)


class SquadDataset(torch.utils.data.Dataset):
    def __init__(self, encodings):
        self.encodings = encodings

    def __getitem__(self, idx):
        return {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}

    def __len__(self):
        return len(self.encodings.input_ids)

train_dataset = SquadDataset(train_encodings)
dev_dataset = SquadDataset(dev_encodings)
test_dataset = SquadDataset(test_encodings)

train_loader = DataLoader(train_dataset, batch_size=6, shuffle=True)
dev_loader = DataLoader(dev_dataset, batch_size=6, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=6, shuffle=True)
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

model = BertForQuestionAnswering.from_pretrained('F:\LK\BioMRC_code-master\\biobert_v1.1_pubmed').to(device)

optim = AdamW(model.parameters(), lr=5e-5)
# optim = AdamW(model.parameters(), lr=3e-5)
# optim = AdamW(model.parameters(), lr=2e-5)

# epochs = 2
epochs = 1
# epochs = 4


whole_train_eval_time = time.time()

train_losses = []
val_losses = []

print_every = 1000

for epoch in range(epochs):
    epoch_time = time.time()

    # Set model in train mode
    model.train()

    loss_of_epoch = 0

    print("############Train############")

    for batch_idx, batch in enumerate(tqdm(train_loader)):

        optim.zero_grad()

        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        start_positions = batch['start_positions'].to(device)
        end_positions = batch['end_positions'].to(device)

        outputs = model(input_ids, attention_mask=attention_mask, start_positions=start_positions,
                        end_positions=end_positions)
        loss = outputs[0]
        # do a backwards pass
        loss.backward()
        # update the weights
        optim.step()
        # Find the total loss
        loss_of_epoch += loss.item()

        if (batch_idx + 1) % print_every == 0:
            print("Batch {:} / {:}".format(batch_idx + 1, len(train_loader)), "\nLoss:", round(loss.item(), 1), "\n")

    loss_of_epoch /= len(train_loader)
    train_losses.append(loss_of_epoch)

    ##########Evaluation##################

    # Set model in evaluation mode
    model.eval()

    print("############Evaluate############")

    loss_of_epoch = 0

    for batch_idx, batch in enumerate(tqdm(dev_loader)):

        with torch.no_grad():

            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            start_positions = batch['start_positions'].to(device)
            end_positions = batch['end_positions'].to(device)

            outputs = model(input_ids, attention_mask=attention_mask, start_positions=start_positions,
                            end_positions=end_positions)
            loss = outputs[0]
            # Find the total loss
            loss_of_epoch += loss.item()

        if (batch_idx + 1) % print_every == 0:
            print("Batch {:} / {:}".format(batch_idx + 1, len(dev_loader)), "\nLoss:", round(loss.item(), 1), "\n")

    loss_of_epoch /= len(dev_loader)
    val_losses.append(loss_of_epoch)

    # Print each epoch's time and train/val loss
    print("\n-------Epoch ", epoch + 1,
          "-------"
          "\nTraining Loss:", train_losses[-1],
          "\nValidation Loss:", val_losses[-1],
          "\nTime: ", (time.time() - epoch_time),
          "\n-----------------------",
          "\n\n")

print("Total training and evaluation time: ", (time.time() - whole_train_eval_time))


# Save model
torch.save(model,"F:\LK\my_model\data_clicr\sort_sentence_3844\\model_Cosine_sort_sentence_train_hasAnsExact_20000_dev_epoch1.pkl")