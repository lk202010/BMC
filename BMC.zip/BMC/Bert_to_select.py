from semantic_text_similarity.models import WebBertSimilarity
from semantic_text_similarity.models import ClinicalBertSimilarity
import nltk
import json
from tqdm import tqdm

nltk.download('punkt')
from nltk import sent_tokenize
import heapq


def sort_sentenct(question, context):
    # web_model = WebBertSimilarity(device='cpu', batch_size=10)  # defaults to GPU prediction

    clinical_model = ClinicalBertSimilarity(device='cuda', batch_size=10)  # defaults to GPU prediction

    # web_model.predict([("She won an olympic gold medal","The women is anolympicchampion")])

    ab_sents = sent_tokenize(context, 'english')
    res = []
    for i in ab_sents:
        # re = web_model.predict([(question, i)])
        re = clinical_model.predict([(question, i)])
        res.append(re.tolist()[0])

    # # 获取list中最大（最小）的n个值
    # heapq.nlargest(len(res), res)

    # 获取list中最大几个值的索引的列表
    sort_index = list(map(res.index, heapq.nlargest(len(res), res)))
    new_context = ""
    for i in sort_index:
        new_context += ab_sents[i]
    return new_context

def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


filepath = "/media/sda2/lk/my_model/data_bioread/no_sort/"
dataset = "test1.0.json"
output_file = "/media/sda2/lk/my_model/Selected paras/BERT/data/BioRead_clinical/"

with open(filepath + dataset, "r") as fin:
    data1 = json.load(fin)
    print()
    count = 0
    data = []
    for da in tqdm(data1["data"][:2000]):
        # question = da["question"]
        # answer = da["answers"]["text"]
        # context = da["context"]
        question = da[0]["question"]
        answer = da[0]["answers"][0]["text"]
        context = da[0]["context"]
        new_context = sort_sentenct(question,context)

        context_word = new_context.split()
        context_split_len = [len(x) for x in context_word]
        ans = answer
        answers = []
        start = 0
        while start < len(context_word) and start > -1:
            try:
                s_index = context_word.index(ans, start)
                answer_start = sum(context_split_len[:s_index]) + 1 * s_index
                answer_end = answer_start + len(ans) - 1
            except:
                break
            answers.append({'answer_start': answer_start, "answer_end": answer_end, 'text': ans})
            start = answer_start + 1
        if len(answers) != 0:
            data.append([{"question": question, "answers": answers, "context": new_context}])
            count += 1
    save = {'data': data, 'version': "BIOMRC_SQuAD"}

    save_json(save, output_file+dataset)


    print(count)


#BIOMRC 6250---6183 运行时间3：51：54



