import json
from tqdm import tqdm


def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


def normalize_text(s):
    """Removing articles and punctuation, and standardizing whitespace are all typical text processing steps."""
    import string, re

    def remove_articles(text):
        regex = re.compile(r"\b(a|an|the)\b", re.UNICODE)
        return re.sub(regex, " ", text)

    def white_space_fix(text):
        return " ".join(text.split())

    def remove_punc(text):
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)

    def lower(text):
        return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))

filepath = "F:\LK\my_model\data_clicr\clicr_squad_Cosine_NoAns\\"
origin_filepath = "F:\LK\BioMRC_code-master\BIOMRC\clicr\\"
dataset = "train1.0.json"

id_ans = dict()
with open(origin_filepath + dataset, "r") as fin:
    origin_data = json.load(fin)
    for data in origin_data["data"]:
        for sample in data["document"]["qas"]:
            ans_list = []
            for ans in sample["answers"]:
                ans_list.append(ans["text"])
            id_ans[sample["id"]] = ans_list

with open(filepath + dataset, "r") as fin:
    data_ = json.load(fin)
    print()

    count = 0
    ans_count = 0
    texts,queries, answers = [], [], []
    for data in tqdm(data_["data"]):
        if len(data) != 0:
            for sample in data:
                texts.append(sample["context"])
                impossible_answer = id_ans[sample["id"]]
                if "[MASK]" in sample["context"]:
                    count+=1
                queries.append(sample["question"])
                answers.append(impossible_answer)
                sample["impossible_answer"] = impossible_answer
                for ans in impossible_answer:
                    an = normalize_text(ans)
                    if an in sample["context"] or ans in sample["context"]:
                        ans_count += 1
                        break
    print(count, ans_count)
    save_json(data_, "F:\LK\my_model\data_clicr\clicr_squad_Cosine_NoAns\\train1.0.json")

"""给NoAns的样本添加可能的答案"""