import json
from pathlib import Path
import torch
from torch.utils.data import DataLoader
import time
from tqdm import tqdm


def get_data(path):
    with open(path, 'rb') as f:
        clicr_dict = json.load(f)["data"]

    texts,queries, answers = [], [], []

    for data in tqdm(clicr_dict):
        for sample in data:
            texts.append(sample["context"])
            queries.append(sample["question"])
            answers.append(sample["answers"][0])

    return texts, queries, answers


# input_file = '/media/sda2/lk/my_model/Selected paras/BERT/data/clinicalbert_sim/'
input_file = '/media/sda2/lk/my_model/Selected paras/BERT/data/BioRead_clinical/'
# train_texts, train_queries, train_answers = get_data(input_file + "train1.0.json")
# dev_texts, dev_queries, dev_answers = get_data(input_file + "dev1.0.json")
test_texts, test_queries, test_answers = get_data(input_file + "test1.0.json")

from transformers import AutoTokenizer,AdamW,BertForQuestionAnswering
tokenizer = AutoTokenizer.from_pretrained("/media/sda2/lk/BioBERT/biobert_v1.1_pubmed")
print("+++++++++++++++++++++")
# train_encodings = tokenizer(train_texts, train_queries, max_length=512, truncation=True, padding=True)
print(1)
# dev_encodings = tokenizer(dev_texts, dev_queries, max_length=512, truncation=True, padding=True)
print(2)
test_encodings = tokenizer(test_texts, test_queries, max_length=512, truncation=True, padding=True)


print("+++++++++++++++++++++")
def add_token_positions(encodings, answers):
    start_positions = []
    end_positions = []

    count = 0
    count1 = 0

    for i in range(len(answers)):
        start_positions.append(encodings.char_to_token(i, answers[i]['answer_start']))
        end_positions.append(encodings.char_to_token(i, answers[i]['answer_end']))

        answers_token = tokenizer(answers[i]["text"])
        a = len(answers_token["input_ids"])
        answers_token_len = a - 2

        # if start position is None, the answer passage has been truncated
        if start_positions[-1] is None:
            # start_positions[-1] = tokenizer.model_max_length
            count1 += 1
            start_positions[-1] = 512

        # if end position is None, the 'char_to_token' function points to the space after the correct token, so add - 1
        if end_positions[-1] is None:
            if start_positions[-1] == 512:
                end_positions[-1] = 512
            else:
                end_positions[-1] = start_positions[-1] + answers_token_len
                # end_positions[-1] = encodings.char_to_token(i, answers[i]['answer_end'] - 1)
                # if end position is still None the answer passage has been truncated
                if end_positions[-1] is None:
                    count += 1
                    end_positions[-1] = tokenizer.model_max_length

    print(count, count1)

    # Update the data in dictionary
    encodings.update({'start_positions': start_positions, 'end_positions': end_positions})

# add_token_positions(train_encodings, train_answers)
# add_token_positions(dev_encodings, dev_answers)
add_token_positions(test_encodings, test_answers)






#train 55599个样本 运行 45:24:15


# bioread test 2000个样本  1小时45分钟  41