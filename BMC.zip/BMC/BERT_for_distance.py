import nltk
import json
from tqdm import tqdm
import numpy as np
from sklearn.metrics.pairwise import euclidean_distances  # 欧氏距离
from sklearn.metrics.pairwise import cosine_similarity  # 余弦距离
from transformers import BertTokenizer, BertForNextSentencePrediction, BertModel
import torch

nltk.download('punkt')
from nltk import sent_tokenize

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(device)
tokenizer = BertTokenizer.from_pretrained("/media/sda2/google_downloads/biobert_v1.1")
model = BertModel.from_pretrained("/media/sda2/google_downloads/biobert_v1.1").to(device)


def similar_count(vec1, vec2, model="cos"):
    '''
    计算距离
    :param vec1: 句向量1
    :param vec2: 句向量2
    :param model: 用欧氏距离还是余弦距离
    :return: 返回的是两个向量的距离得分
    '''
    return cosine_similarity(vec1, vec2)[0][0], euclidean_distances(vec1, vec2)[0][0]


def sort_sent_distance(query, context):
    cont_list = sent_tokenize(context)
    token_query = tokenizer(query, return_tensors="pt").to(device)
    query_output = model(**token_query).pooler_output.detach().cpu().numpy()
    score_cos_list = []
    score_ou_list = []
    for con in cont_list:
        token_context = tokenizer(con, truncation=True, return_tensors="pt").to(device)
        # print(token_context["input_ids"].shape)
        token_output = model(**token_context).pooler_output.detach().cpu().numpy()
        score_cos, score_ou = similar_count(query_output, token_output)
        score_cos_list.append(score_cos)
        score_ou_list.append(score_ou)
        # print(score)

    sort_cos_index = np.argsort(score_cos_list)[::-1]
    sort_ou_index = np.argsort(score_ou_list)[::-1]

    sort_cos_context = ""
    for sort_cos_idx in sort_cos_index:
        sort_cos_context += "".join(x for x in cont_list[sort_cos_idx])
        sort_cos_context += " "

    sort_ou_context = ""
    for sort_ou_idx in sort_ou_index:
        sort_ou_context += "".join(x for x in cont_list[sort_ou_idx])
        sort_ou_context += " "

    return sort_cos_context, sort_ou_context


def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


def get_answer(real_answer, new_context):
    new_answer = []
    start = 0
    while start < len(new_context) and start > -1:
        try:
            answer_start = new_context.index(real_answer, start)
            answer_end = answer_start + len(real_answer)
        except:
            break
        new_answer.append({'answer_start': answer_start, 'answer_end': answer_end, 'text': real_answer})
        # answers.append({'start': answer_start,"end":answer_end, 'text': a})
        start = answer_start + 1
    return new_answer


filepath = "/media/sda2/lk/my_model/Selected paras/BERT/CliCR_v2_mask_to_原始/"
dataset = "dev1.0.json"
output_cos_file = "/media/sda2/lk/my_model/Selected paras/BERT/data/CliCR_sort_bert_cos_distance"
output_ou_file = "/media/sda2/lk/my_model/Selected paras/BERT/data/CliCR_sort_bert_ou_distance"

with open(filepath + dataset, "r") as fin:
    data1 = json.load(fin)
    print()
    count_cos, count_ou = 0, 0
    data_cos = []
    data_ou = []
    for da in tqdm(data1["data"], total=len(data1["data"])):
        # question = da["question"]
        # answer = da["answers"]["text"]
        # context = da["context"]
        for i in range(len(da)):
            query = da[i]["question"]
            answer = da[i]["answers"][0]["text"]
            context = da[i]["context"]
            # new_context = sort_sentenct(question,context)
            new_cos_context, new_ou_context = sort_sent_distance(query, context)

            context_cos_word = new_cos_context.split()
            context_cos_split_len = [len(x) for x in context_cos_word]

            if len(answer) != 0:
                real_answer = answer
                new_cos_answer = get_answer(real_answer, new_cos_context)
                if len(new_cos_answer) != 0:
                    data_cos.append([{"question": query, "answers": new_cos_answer, "context": new_cos_context}])
                    count_cos += 1

            # ++++++++++++++++++
            context_ou_word = new_ou_context.split()
            context_ou_split_len = [len(x) for x in context_ou_word]

            if len(answer) != 0:
                real_answer = answer
                new_ou_answer = get_answer(real_answer, new_ou_context)
                if len(new_ou_answer) != 0:
                    data_ou.append([{"question": query, "answers": new_ou_answer, "context": new_ou_context}])
                    count_ou += 1

    save1 = {'data': data_cos, 'version': "bert_distance_cos"}
    save2 = {'data': data_ou, 'version': "bert_distance_ou"}

    save_json(save1, output_cos_file + dataset)
    save_json(save2, output_ou_file + dataset)

    print(count_cos)
    print(count_ou)




filepath = "/media/sda2/lk/my_model/Selected paras/BERT/CliCR_v2_mask_to_原始/"
dataset = "test1.0.json"
output_cos_file = "/media/sda2/lk/my_model/Selected paras/BERT/data/CliCR_sort_bert_cos_distance"
output_ou_file = "/media/sda2/lk/my_model/Selected paras/BERT/data/CliCR_sort_bert_ou_distance"

with open(filepath + dataset, "r") as fin:
    data1 = json.load(fin)
    print()
    count_cos, count_ou = 0, 0
    data_cos = []
    data_ou = []
    for da in tqdm(data1["data"], total=len(data1["data"])):
        # question = da["question"]
        # answer = da["answers"]["text"]
        # context = da["context"]
        for i in range(len(da)):
            query = da[i]["question"]
            answer = da[i]["answers"][0]["text"]
            context = da[i]["context"]
            # new_context = sort_sentenct(question,context)
            new_cos_context, new_ou_context = sort_sent_distance(query, context)

            context_cos_word = new_cos_context.split()
            context_cos_split_len = [len(x) for x in context_cos_word]

            if len(answer) != 0:
                real_answer = answer
                new_cos_answer = get_answer(real_answer, new_cos_context)
                if len(new_cos_answer) != 0:
                    data_cos.append([{"question": query, "answers": new_cos_answer, "context": new_cos_context}])
                    count_cos += 1

            # ++++++++++++++++++
            context_ou_word = new_ou_context.split()
            context_ou_split_len = [len(x) for x in context_ou_word]

            if len(answer) != 0:
                real_answer = answer
                new_ou_answer = get_answer(real_answer, new_ou_context)
                if len(new_ou_answer) != 0:
                    data_ou.append([{"question": query, "answers": new_ou_answer, "context": new_ou_context}])
                    count_ou += 1

    save1 = {'data': data_cos, 'version': "bert_distance_cos"}
    save2 = {'data': data_ou, 'version': "bert_distance_ou"}

    save_json(save1, output_cos_file + dataset)
    save_json(save2, output_ou_file + dataset)

    print(count_cos)
    print(count_ou)


