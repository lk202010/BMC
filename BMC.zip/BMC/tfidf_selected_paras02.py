import pandas as pd
import numpy as np
from nltk.corpus import stopwords
import nltk
from tqdm import tqdm
nltk.download('stopwords')
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics.pairwise import euclidean_distances
import json



print("+++++++++++++++++++")

origin_filepath = "F:\LK\BioMRC_code-master\BIOMRC\clicr\\"
dataset = "dev1.0.json"

id_ans = dict()
with open(origin_filepath + dataset, "r") as fin:
    origin_data = json.load(fin)
    for data in origin_data["data"]:
        for sample in data["document"]["qas"]:
            ans_list = []
            for ans in sample["answers"]:
                ans_list.append(ans["text"])
            id_ans[sample["id"]] = ans_list

with open("F:\LK\BioMRC_code-master\clicr\data\clicr_squad_v2_MASK\\dev1.0.json", "r") as fin:
    data = json.load(fin)
    print()

def select_paras(df):
    documents_df = pd.DataFrame(df, columns=['documents'])

    # removing special characters and stop words from the text
    stop_words_l = stopwords.words('english')
    documents_df['documents_cleaned'] = documents_df.documents.apply(lambda x: " ".join(
        re.sub(r'[^a-zA-Z]', ' ', w).lower() for w in x.split() if
        re.sub(r'[^a-zA-Z]', ' ', w).lower() not in stop_words_l))

    tfidfvectoriser = TfidfVectorizer()
    tfidfvectoriser.fit(documents_df.documents_cleaned)
    tfidf_vectors = tfidfvectoriser.transform(documents_df.documents_cleaned)

    pairwise_similarities = np.dot(tfidf_vectors, tfidf_vectors.T).toarray()
    pairwise_differences = euclidean_distances(tfidf_vectors)

    similar_ix_Cosine = most_similar(0, df, pairwise_similarities, 'Cosine Similarity')
    similar_ix_Euclidean = most_similar(0, df, pairwise_differences, 'Euclidean Distance')

    return similar_ix_Cosine.tolist(), similar_ix_Euclidean.tolist()


def most_similar(doc_id,documents_df, similarity_matrix, matrix):
    if matrix == 'Cosine Similarity':
        similar_ix = np.argsort(similarity_matrix[doc_id])[::-1]
    elif matrix == 'Euclidean Distance':
        similar_ix = np.argsort(similarity_matrix[doc_id])
    return similar_ix


def remove_entity_marks(txt):
    return txt.replace("BEG__", "").replace("__END", "").replace("\n\n"," ").replace("\n"," ")


def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))

sample = []
max_len = 0
count = 0
for data in tqdm(data["data"]):

    a = data["paragraphs"][0]["context"]
    b = remove_entity_marks(a).split(" .")
    qas = []
    qas_no = []
    for qa in data["paragraphs"][0]["qas"]:
        ques = remove_entity_marks(qa["question"])

        b.insert(0, ques)
        similar_ix_Cosine, similar_ix_Euclidean = select_paras(b)

        top_k_paras = []
        for ix in similar_ix_Cosine[1:4]:
            top_k_paras.append(b[ix])

        new_context = "".join(p for p in top_k_paras)
        if len(new_context) > max_len:
            max_len = len(new_context)
        # 找答案
        b.pop(0)
        if len(qa["answers"]) != 0:
            real_answer = qa["answers"][0]["text"]
            new_answer = []
            start = 0
            while start < len(new_context) and start > -1:
                try:
                    answer_start = new_context.index(real_answer, start)
                    answer_end = answer_start + len(real_answer)
                except:
                    break
                new_answer.append({'answer_start': answer_start, 'answer_end':answer_end, 'text': real_answer})
                # answers.append({'start': answer_start,"end":answer_end, 'text': a})
                start = answer_start+1
            if len(new_answer) != 0:
                qas.append({"question":ques, "id":qa["id"], "answers":new_answer, "context":new_context})
                count += 1
            else:
                answer = id_ans[qa["id"]]
                qas.append({"question": ques, "id": qa["id"], "answers":answer, "context": new_context})
                count += 1

    sample.append(qas)


save = {'data': sample, 'version': "select_paras_Top_3"}
print(max_len, count)

save_json(save, "F:\LK\my_model\data_clicr\clicr_squad_Cosine_HasAnsExact_NoAns_3844\\dev1.0.json")
"""选择能找到答案的样本，通过选择top3的句子，有些有答案的句子也没有答案了，再添加可能的答案"""
