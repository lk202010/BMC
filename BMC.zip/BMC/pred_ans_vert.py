import random
import numpy as np
import os
import torch


def predict(model, context, query):
    inputs = tokenizer.encode_plus(query, context, max_length=512, truncation=True, return_tensors='pt')
    # inputs = tokenizer.encode_plus(context, query, max_length=512, truncation=True, return_tensors='pt')

    input_ids = inputs["input_ids"].to(device)
    token_type_ids = inputs["token_type_ids"].to(device)
    attention_mask = inputs["attention_mask"].to(device)

    outputs = model(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask)
    # outputs = model(**inputs)

    answer_start = torch.argmax(outputs[0])  # get the most likely beginning of answer with the argmax of the score
    answer_end = torch.argmax(outputs[1])

    # print(input_ids.detach().cpu().numpy().tolist()[0])
    context_len = input_ids.detach().cpu().numpy().tolist()[0].index(102) - 1
    max_answer_length = 512 - context_len
    min_answer_length = 1
    answer_start_np = outputs[0].detach().cpu().numpy()
    answer_end_np = outputs[1].detach().cpu().numpy()
    # print(answer_start_np)
    # print(answer_end_np)
    answer_start_index_sort = np.argsort(answer_start_np)[0][::-1]
    answer_end_index_sort = np.argsort(answer_end_np)[0][::-1]

    # print("++++++++++++++++++++++")
    # print(answer_start_index_sort)
    # print(answer_end_index_sort)
    # print(context_len)
    # print("++++++++++++++++++++++")
    def answer_vert(answer_start_index_sort, answer_end_index_sort, context_len, max_answer_length, min_answer_length):
        for start in answer_start_index_sort:
            if start < context_len:
                continue
            for end in answer_end_index_sort:
                length = end - start + 1
                if end <= 512 and length < max_answer_length and length > min_answer_length:
                    return start, end

    start, end = answer_vert(answer_start_index_sort, answer_end_index_sort, context_len, max_answer_length,
                             min_answer_length)

    answer = tokenizer.convert_tokens_to_string(
        tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][start:end]))
    answer2 = tokenizer.convert_tokens_to_string(
        tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][answer_start:answer_end]))

    # print("++++++++++++++++++++++++++++++++")
    # print("answer_vert:", start, end)
    # print("pred:",answer_start, answer_end)
    # print("answer_vert:",answer)
    # print("answer2:", answer2)
    # # print(answer_start_np)
    # # print(answer_end_np)
    # print("++++++++++++++++++++++++++++++++")

    return answer, answer_start - 1, answer_end - 1, answer2
    # return answer2, answer_start-1, answer_end-1, answer