import json
# with open("F:/LK/BioMRC_code-master/BIOMRC/dataset/biomrc_tiny_B/dataset_tiny_B.json", "r") as fin:
with open("F:/LK/BioMRC_code-master/BIOMRC/dataset/biomrc_small_B/dataset_val_small_B.json", "r") as fin:
    data = json.load(fin)

print(data)
abstracts = data["abstracts"]
titles = data["titles"]
entities_list = data["entities_list"]
answers = data["answers"]

# for i, (ab, ti, en_li, an) in zip(abstracts, titles, entities_list, answers):
#     print(ab, ti, en_li, an)
with open("F:/LK/BioMRC_code-master/BIOMRC/y/dataset_val_small_B.json", "w") as fout:

    for i in range(len(abstracts)):
        print({"abstracts":abstracts[i], "titles":titles[i], "entities_list":entities_list[i], "answers":answers[i]})
        data_json = json.dumps({"abstracts":abstracts[i], "titles":titles[i], "entities_list":entities_list[i], "answers":answers[i]})
        fout.write(data_json)