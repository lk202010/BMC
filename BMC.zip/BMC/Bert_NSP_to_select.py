from semantic_text_similarity.models import WebBertSimilarity
from semantic_text_similarity.models import ClinicalBertSimilarity
import nltk
import json
from tqdm import tqdm
import numpy as np
from transformers import BertTokenizer, BertForNextSentencePrediction
import torch
nltk.download('punkt')
from nltk import sent_tokenize

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
tokenizer = BertTokenizer.from_pretrained("/media/sda2/lk/Bert")
model = BertForNextSentencePrediction.from_pretrained("/media/sda2/lk/Bert").to(device)


def sort_sent_NSP(query, context):
    cont_list = sent_tokenize(context)
    logits_list = []
    for con in cont_list:
        encoding = tokenizer(query, con, return_tensors="pt").to(device)
        # input_ids = encoding['input_ids'].to(device)
        # token_type_ids = encoding['token_type_ids'].to(device)
        # attention_mask = encoding['attention_mask'].to(device)
        outputs = model(**encoding, labels=torch.LongTensor([1]))
        logits = outputs.logits  # 两个数分别代表不是下一句，是下一句（0，1）的概率
        logits_list.append(logits.detach().cpu().numpy().tolist()[0][1])

    # print(logits_list)
    sort_index = np.argsort(logits_list)[::-1]
    # print(sort_index)
    sort_context = ""
    for sort_idx in sort_index:
        sort_context += "".join(cont_list[sort_idx])
        sort_context += " "
    return sort_context


def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


def get_answer(real_answer, new_context):
    new_answer = []
    start = 0
    while start < len(new_context) and start > -1:
        try:
            answer_start = new_context.index(real_answer, start)
            answer_end = answer_start + len(real_answer)
        except:
            break
        new_answer.append({'answer_start': answer_start, 'answer_end': answer_end, 'text': real_answer})
        # answers.append({'start': answer_start,"end":answer_end, 'text': a})
        start = answer_start + 1
    return new_answer

filepath = "/media/sda2/lk/my_model/Selected paras/BERT/CliCR_v2_mask_to_原始/"
dataset = "test1.0.json"
output_file = "/media/sda2/lk/my_model/data_biomrc/Bert_sort_Lite_A/"

with open(filepath + dataset, "r") as fin:
    data1 = json.load(fin)
    print()
    count = 0
    data = []
    for da in tqdm(data1["data"],total=len(data1["data"])):
        # question = da["question"]
        # answer = da["answers"]["text"]
        # context = da["context"]
        for i in range(len(da)):
            query = da[i]["question"]
            answer = da[i]["answers"][0]["text"]
            context = da[i]["context"]
            # new_context = sort_sentenct(question,context)
            new_context = sort_sent_NSP(query, context)

            context_word = new_context.split()
            context_split_len = [len(x) for x in context_word]


            if len(answer) != 0:
                real_answer = answer
                new_answer = get_answer(real_answer, new_context)
                if len(new_answer) != 0:
                    data.append([{"question": query, "answers": new_answer, "context": new_context}])
                    count += 1
    save = {'data': data, 'version': "BIOMRC_SQuAD"}

    save_json(save, output_file+dataset)


    print(count)



