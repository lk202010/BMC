import json
from tqdm import tqdm
filepath = "/media/sda2/lk/my_model/data_biomrc/Bert_sort_Lite_A/"
dataset = "test1.0.json"


with open(filepath + dataset, "r") as fin:
    data = json.load(fin)
    print()
    count = 0
    for da in data["data"]:
        count += len(da)

    print(count)


# filepath = "F:\LK\my_model\data_biomrc\Lite_B\\"
# dataset = "dev1.0.json"
#
#
# with open(filepath + dataset, "r") as fin:
#     data1 = json.load(fin)
#     print()
#     count = 0
#     for da in data1["data"]:
#         count += len(da)
#
#     print(count)