import torch
from transformers import BertForQuestionAnswering
model = BertForQuestionAnswering.from_pretrained('F:\LK\BioMRC_code-master\Bio_CliniaclBERT')
# Save model
torch.save(model,"F:\LK\my_model\Best_model\\Bio_CliniaclBERT_origin.pkl")