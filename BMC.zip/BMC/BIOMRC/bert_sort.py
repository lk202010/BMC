
import pandas as pd
import numpy as np
from nltk.corpus import stopwords
import nltk
from tqdm import tqdm
nltk.download('stopwords')
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics.pairwise import euclidean_distances
from transformers import AutoTokenizer, BertForMaskedLM
import torch
import json

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

tokenizer = AutoTokenizer.from_pretrained("/media/sda2/lk/BioBERT/biobert_v1.1_pubmed")
model = BertForMaskedLM.from_pretrained("/media/sda2/lk/BioBERT/biobert_v1.1_pubmed").to(device)

def select_paras(df):
    documents_df = pd.DataFrame(df, columns=['documents'])

    # removing special characters and stop words from the text
    stop_words_l = stopwords.words('english')
    documents_df['documents_cleaned'] = documents_df.documents.apply(lambda x: " ".join(
        re.sub(r'[^a-zA-Z]', ' ', w).lower() for w in x.split() if
        re.sub(r'[^a-zA-Z]', ' ', w).lower() not in stop_words_l))
    # a = documents_df["documents_cleaned"].tolist()
    token_tensor = tokenizer(documents_df["documents_cleaned"].tolist(),padding=True,truncation=True,return_tensors="pt")
    output = model(token_tensor["input_ids"].to(device))
    cls_output = output[0][:,0,:].detach().cpu().numpy()
    similar_ix_Cosine = np.argsort(cosine_similarity(cls_output)[0])[::-1]
    similar_ix_Euclidean = np.argsort(euclidean_distances(cls_output)[0])


    return similar_ix_Cosine.tolist(), similar_ix_Euclidean.tolist()


def most_similar(doc_id,documents_df, similarity_matrix, matrix):
    if matrix == 'Cosine Similarity':
        similar_ix = np.argsort(similarity_matrix[doc_id])[::-1]
    elif matrix == 'Euclidean Distance':
        similar_ix = np.argsort(similarity_matrix[doc_id])
    return similar_ix


def remove_entity_marks(txt):
    return txt.replace("BEG__", "").replace("__END", "").replace("\n\n"," ").replace("\n"," ")


def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))


def get_answer(real_answer, new_context):
    new_answer = []
    start = 0
    while start < len(new_context) and start > -1:
        try:
            answer_start = new_context.index(real_answer, start)
            answer_end = answer_start + len(real_answer)
        except:
            break
        new_answer.append({'answer_start': answer_start, 'answer_end': answer_end, 'text': real_answer})
        # answers.append({'start': answer_start,"end":answer_end, 'text': a})
        start = answer_start + 1
    return new_answer

def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))

def convert(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as fi:
        data_ = json.load(fi)
        count = 0
        data = []
        context = data_["abstracts"]
        query = [a.replace('.XXXX', ' [MASK]').replace('XXXX', '[MASK]') for a in data_["titles"]]
        answer = [an.split(" ::")[0] for an in data_["answers"]]
        # for q, a in zip(query, answer):
        #     qas.append({"question":q, "answer":a})
        for con, qa, an in zip(context, query, answer):
            b = con.split(". ")
            b.insert(0, qa)
            similar_ix_Cosine, similar_ix_Euclidean = select_paras(b)
            # top_k_paras = []
            # for ix in similar_ix_Cosine[1:]:
            #     z = ix
            #     top_k_paras.append(b[ix])

            new_context = " ".join(b[ix] + " ." for ix in similar_ix_Cosine[1:])
            new_context = new_context.lstrip()

            context_word = new_context.split()
            new_context = " ".join(word for word in context_word)
            new_context = new_context.lstrip()
            context_split_len = [len(x) for x in context_word]
            ans = an
            answers = []
            start = 0
            while start < len(context_word) and start > -1:
                try:
                    s_index = context_word.index(ans, start)
                    answer_start = sum(context_split_len[:s_index]) + 1*s_index
                    answer_end = answer_start + len(ans) - 1
                except:
                    break
                answers.append({'answer_start': answer_start,"answer_end":answer_end, 'text': ans})
                start = answer_start+1
            if len(answers) != 0:
                data.append([{"question":qa, "answers":answers, "context":new_context}])
                count += 1
        save = {'data': data, 'version': "BIOMRC_SQuAD"}

        save_json(save, output_file)
        print(count)


def sort_sentence_bert(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as fi:
        data1 = json.load(fi)["data"]
        count = 0
        data = []
        for da in tqdm(data1):
            qa = da[0]["question"]
            con = da[0]["context"]
            an = da[0]["answers"][0]["text"]

            b = con.split(". ")
            b.insert(0, qa)
            similar_ix_Cosine, similar_ix_Euclidean = select_paras(b)
            # top_k_paras = []
            # for ix in similar_ix_Cosine[1:]:
            #     z = ix
            #     top_k_paras.append(b[ix])

            new_context = " ".join(b[ix] + " ." for ix in similar_ix_Cosine[1:])
            new_context = new_context.lstrip()

            context_word = new_context.split()
            new_context = " ".join(word for word in context_word)
            new_context = new_context.lstrip()
            context_split_len = [len(x) for x in context_word]
            ans = an
            answers = []
            start = 0
            while start < len(context_word) and start > -1:
                try:
                    s_index = context_word.index(ans, start)
                    answer_start = sum(context_split_len[:s_index]) + 1 * s_index
                    answer_end = answer_start + len(ans) - 1
                except:
                    break
                answers.append({'answer_start': answer_start, "answer_end": answer_end, 'text': ans})
                start = answer_start + 1
            if len(answers) != 0:
                data.append([{"question": qa, "answers": answers, "context": new_context}])
                count += 1

            save = {'data': data, 'version': "BIOMRC_SQuAD_Bert_CS"}

            save_json(save, output_file)

    print(count)


input_file = "/media/sda2/lk/my_model/data_biomrc/Lite/train1.0.json"
output_file = "/media/sda2/lk/my_model/data_biomrc/Bert_sort_Lite_A_CS/train1.0.json"
sort_sentence_bert(input_file, output_file)

input_file = "/media/sda2/lk/my_model/data_biomrc/Lite/dev1.0.json"
output_file = "/media/sda2/lk/my_model/data_biomrc/Bert_sort_Lite_A_CS/dev1.0.json"
sort_sentence_bert(input_file, output_file)

# input_file = "/media/sda2/lk/my_model/data_biomrc/Lite/test1.0.json"
# output_file = "/media/sda2/lk/my_model/data_biomrc/Bert_sort_Lite_A_CS/test1.0.json"
# sort_sentence_bert(input_file, output_file)


# input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_A\\dataset_train_small.json"
# output_file = "F:\LK\my_model\model_biomrc\sort\Lite_A\\train1.0.json"
# convert(input_file, output_file)
#
# input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_A\\dataset_val_small.json"
# output_file = "F:\LK\my_model\model_biomrc\sort\Lite_A\\dev1.0.json"
# convert(input_file, output_file)
#
# input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_A\\dataset_test_small.json"
# output_file = "F:\LK\my_model\model_biomrc\sort\Lite_A\\test1.0.json"
# convert(input_file, output_file)
#
#
# input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_B\\dataset_train_small_B.json"
# output_file = "F:\LK\my_model\model_biomrc\sort\Lite_B\\train1.0.json"
# convert(input_file, output_file)
#
# input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_B\\dataset_val_small_B.json"
# output_file = "F:\LK\my_model\model_biomrc\sort\Lite_B\\dev1.0.json"
# convert(input_file, output_file)
#
# input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_B\\dataset_test_small_B.json"
# output_file = "F:\LK\my_model\model_biomrc\sort\Lite_B\\test1.0.json"
# convert(input_file, output_file)