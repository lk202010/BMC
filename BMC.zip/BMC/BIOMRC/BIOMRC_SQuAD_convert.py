import json
from tqdm import tqdm

def save_json(obj, filename):
    with open(filename, "w") as out:
        json.dump(obj, out, separators=(',', ':'))

def convert(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as fi:
        data_ = json.load(fi)
        count = 0
        data = []
        context = data_["abstracts"]
        query = [a.replace('.XXXX', ' [MASK]').replace('XXXX', '[MASK]') for a in data_["titles"]]
        answer = [an.split(" ::")[0] for an in data_["answers"]]
        # for q, a in zip(query, answer):
        #     qas.append({"question":q, "answer":a})
        for con, qa, an in zip(context, query, answer):
            context_word = con.split()
            context_split_len = [len(x) for x in context_word]
            ans = an
            answers = []
            start = 0
            while start < len(context_word) and start > -1:
                try:
                    s_index = context_word.index(ans, start)
                    answer_start = sum(context_split_len[:s_index]) + 1*s_index
                    answer_end = answer_start + len(ans) - 1
                except:
                    break
                answers.append({'answer_start': answer_start,"answer_end":answer_end, 'text': ans})
                start = answer_start+1
            if len(answers) != 0:
                data.append([{"question":qa, "answers":answers, "context":con}])
                count += 1
        save = {'data': data, 'version': "BIOMRC_SQuAD"}

        save_json(save, output_file)
        print(count)

input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_B\\dataset_train_small_B.json"
output_file = "F:\LK\my_model\data_biomrc\\train1.0.json"
convert(input_file, output_file)

input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_B\\dataset_val_small_B.json"
output_file = "F:\LK\my_model\data_biomrc\\dev1.0.json"
convert(input_file, output_file)

input_file = "F:\LK\BioMRC_code-master\BIOMRC\dataset\\biomrc_small_B\\dataset_test_small_B.json"
output_file = "F:\LK\my_model\data_biomrc\\test1.0.json"
convert(input_file, output_file)