import json
import torch
from torch.utils.data import DataLoader
import time
from tqdm import tqdm
# from my_model.model_biomrc.sort.model_eval import normalize_text, compute_f1, compute_exact_match
import random


def get_data(path):
    with open(path, 'rb') as f:
        biomrc_dict = json.load(f)["data"]

    texts,queries, answers = [], [], []

    for data in tqdm(biomrc_dict):
        for sample in data:
            texts.append(sample["context"])
            queries.append(sample["question"])
            answers.append(sample["answers"][0])

    return texts, queries, answers

train_texts, train_queries, train_answers = get_data("/media/sda2/lk/my_model/data_biomrc/Lite/train1.0.json")
# train_texts, train_queries, train_answers = train_texts[:50000], train_queries[:50000], train_answers[:50000]
dev_texts, dev_queries, dev_answers = get_data("/media/sda2/lk/my_model/data_biomrc/Lite/dev1.0.json")
test_texts, test_queries, test_answers = get_data("/media/sda2/lk/my_model/data_biomrc/Lite/test1.0.json")



from transformers import AutoTokenizer,AdamW,BertForQuestionAnswering
tokenizer = AutoTokenizer.from_pretrained("/media/sda2/lk/BioBERT/biobert_v1.1_pubmed")

train_encodings = tokenizer(train_texts, train_queries, max_length=512, truncation=True, padding=True)
dev_encodings = tokenizer(dev_texts, dev_queries, max_length=512, truncation=True, padding=True)
test_encodings = tokenizer(test_texts, test_queries, max_length=512, truncation=True, padding=True)


def add_token_positions(encodings, answers):
    start_positions = []
    end_positions = []

    count = 0
    count1 = 0

    for i in range(len(answers)):
        start_positions.append(encodings.char_to_token(i, answers[i]['answer_start']))
        end_positions.append(encodings.char_to_token(i, answers[i]['answer_end']))

        answers_token = tokenizer(answers[i]["text"])
        a = len(answers_token["input_ids"])
        answers_token_len = a - 2

        # if start position is None, the answer passage has been truncated
        if start_positions[-1] is None:
            # start_positions[-1] = tokenizer.model_max_length
            count1 += 1
            start_positions[-1] = 512

        # if end position is None, the 'char_to_token' function points to the space after the correct token, so add - 1
        if end_positions[-1] is None:
            if start_positions[-1] == 512:
                end_positions[-1] = 512
            else:
                end_positions[-1] = start_positions[-1] + answers_token_len
                # end_positions[-1] = encodings.char_to_token(i, answers[i]['answer_end'] - 1)
                # if end position is still None the answer passage has been truncated
                if end_positions[-1] is None:
                    count += 1
                    end_positions[-1] = tokenizer.model_max_length

    print(count, count1)

    # Update the data in dictionary
    encodings.update({'start_positions': start_positions, 'end_positions': end_positions})


add_token_positions(train_encodings, train_answers)
add_token_positions(dev_encodings, dev_answers)
add_token_positions(test_encodings, test_answers)


class SquadDataset(torch.utils.data.Dataset):
    def __init__(self, encodings):
        self.encodings = encodings

    def __getitem__(self, idx):
        return {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}

    def __len__(self):
        return len(self.encodings.input_ids)

def predict(model ,context, query):
    # inputs = tokenizer.encode_plus(query, context, max_length=512, truncation=True, return_tensors='pt')
    inputs = tokenizer.encode_plus(context, query, max_length=512, truncation=True, return_tensors='pt')

    input_ids = inputs["input_ids"].to(device)
    token_type_ids = inputs["token_type_ids"].to(device)
    attention_mask = inputs["attention_mask"].to(device)

    outputs = model(input_ids=input_ids, token_type_ids=token_type_ids, attention_mask=attention_mask)
    # outputs = model(**inputs)
    answer_start = torch.argmax(outputs[0])  # get the most likely beginning of answer with the argmax of the score
    answer_end = torch.argmax(outputs[1]) + 1

    answer = tokenizer.convert_tokens_to_string(
        tokenizer.convert_ids_to_tokens(inputs['input_ids'][0][answer_start:answer_end]))

    return answer

def give_an_answer(model, context,query):

  prediction = predict(model, context,query)
  return prediction

def eval_pred(model, filepath, dataset, out_put_file):
    with open(filepath + dataset, "r") as fin:
        data = json.load(fin)

    texts,queries, answers = [], [], []

    for data in tqdm(data["data"]):
        for sample in data:
            texts.append(sample["context"])
            queries.append(sample["question"])
            answers.append(sample["answers"][0]["text"])

    count = 0
    acc = 0
    towrite = []
    for q, a, c in tqdm(zip(queries, answers, texts), total=len(queries)):
        count += 1
        prediction = give_an_answer(model, c, q)
        prediction = prediction.replace(" ","")
        # print(prediction ," : ", a)
        if prediction == a:
            acc += 1
        towrite.append('{}::{}\n'.format(prediction, a))


    total_acc = acc/count
    print(acc, count)
    print("Acc:",total_acc)

    out_file = out_put_file.split(".txt")[0]  + '_' + str(total_acc*100)[:6] + ".txt"

    with open(out_file, 'w' , encoding="utf-8") as f:
        f.write(''.join(towrite))
        f.close()
        print("successful write!")


def predicts(model, input_file, output_file, dataset):
    model = model
    filepath = input_file
    output_file = output_file
    dataset = dataset
    eval_pred(model, filepath, dataset, output_file)


train_dataset = SquadDataset(train_encodings)
dev_dataset = SquadDataset(dev_encodings)
test_dataset = SquadDataset(test_encodings)

train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
dev_loader = DataLoader(dev_dataset, batch_size=8, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=8, shuffle=True)
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

model = BertForQuestionAnswering.from_pretrained('/media/sda2/lk/BioBERT/biobert_v1.1_pubmed').to(device)

epochs = 4
file_path = "/media/sda2/lk/my_model/model_biomrc/Lite A/调参/"
model_name = "Biobert"
data_Classification = "A"
learning_rate = 5e-5


optim = AdamW(model.parameters(), lr=learning_rate)
# optim = AdamW(model.parameters(), lr=3e-5)
# optim = AdamW(model.parameters(), lr=2e-5)

# epochs = 2
epochs = 4
# epochs = 4


whole_train_eval_time = time.time()

train_losses = []
val_losses = []

print_every = 1000

for epoch in range(epochs):
    epoch_time = time.time()

    # Set model in train mode
    model.train()

    loss_of_epoch = 0

    print("############Train############")

    for batch_idx, batch in enumerate(tqdm(train_loader)):

        optim.zero_grad()

        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        start_positions = batch['start_positions'].to(device)
        end_positions = batch['end_positions'].to(device)

        outputs = model(input_ids, attention_mask=attention_mask, start_positions=start_positions,
                        end_positions=end_positions)
        loss = outputs[0]
        # do a backwards pass
        loss.backward()
        # update the weights
        optim.step()
        # Find the total loss
        loss_of_epoch += loss.item()

        if (batch_idx + 1) % print_every == 0:
            print("Batch {:} / {:}".format(batch_idx + 1, len(train_loader)), "\nLoss:", round(loss.item(), 1), "\n")

    loss_of_epoch /= len(train_loader)
    train_losses.append(loss_of_epoch)

    ##########Evaluation##################

    # Set model in evaluation mode
    model.eval()

    print("############Evaluate############")

    loss_of_epoch = 0

    for batch_idx, batch in enumerate(tqdm(dev_loader)):

        with torch.no_grad():

            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            start_positions = batch['start_positions'].to(device)
            end_positions = batch['end_positions'].to(device)

            outputs = model(input_ids, attention_mask=attention_mask, start_positions=start_positions,
                            end_positions=end_positions)
            loss = outputs[0]
            # Find the total loss
            loss_of_epoch += loss.item()

        if (batch_idx + 1) % print_every == 0:
            print("Batch {:} / {:}".format(batch_idx + 1, len(dev_loader)), "\nLoss:", round(loss.item(), 1), "\n")

    loss_of_epoch /= len(dev_loader)
    val_losses.append(loss_of_epoch)

    # Print each epoch's time and train/val loss
    print("\n-------Epoch ", epoch + 1,
          "-------"
          "\nTraining Loss:", train_losses[-1],
          "\nValidation Loss:", val_losses[-1],
          "\nTime: ", (time.time() - epoch_time),
          "\n-----------------------",
          "\n\n")
    if epoch == 0:
        save_model_file = file_path + "/model" + "/" + model_name + "_" + data_Classification + "_epochs" + str(
            epoch + 1) + "_lr" + str(learning_rate) + ".pkl"  # 保存模型的地址

        torch.save(model.state_dict(), save_model_file)
        input_file = "/media/sda2/lk/my_model/model_biomrc/sort/Lite_A/"
        output_dev_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + \
                          "_lr" + str(learning_rate) + "_dev.txt"
        output_test_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + "_lr" + str(learning_rate) + "_dev.txt"
        model_test = BertForQuestionAnswering.from_pretrained('/media/sda2/lk/BioBERT/biobert_v1.1_pubmed').to(device)
        model_test.load_state_dict(
            torch.load(save_model_file))
        model_test.eval()
        predicts(model_test, input_file, output_dev_file, dataset="dev1.0.json")
        predicts(model_test, input_file, output_test_file, dataset="test1.0.json")

    if epoch == 1:
        save_model_file = file_path + "/model" + "/" + model_name + "_" + data_Classification + "_epochs" + str(
            epoch + 1) + "_lr" + str(learning_rate) + ".pkl"  # 保存模型的地址

        torch.save(model.state_dict(), save_model_file)
        input_file = "/media/sda2/lk/my_model/model_biomrc/sort/Lite_A/"
        output_dev_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + \
                          "_lr" + str(learning_rate) + "_dev.txt"
        output_test_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + "_lr" + str(learning_rate) + "_dev.txt"
        model_test = BertForQuestionAnswering.from_pretrained('/media/sda2/lk/BioBERT/biobert_v1.1_pubmed').to(device)
        model_test.load_state_dict(
            torch.load(save_model_file))
        model_test.eval()
        predicts(model_test, input_file, output_dev_file, dataset="dev1.0.json")
        predicts(model_test, input_file, output_test_file, dataset="test1.0.json")

    if epoch == 2:
        save_model_file = file_path + "/model" + "/" + model_name + "_" + data_Classification + "_epochs" + str(
            epoch + 1) + "_lr" + str(learning_rate) + ".pkl"  # 保存模型的地址

        torch.save(model.state_dict(), save_model_file)
        input_file = "/media/sda2/lk/my_model/model_biomrc/sort/Lite_A/"
        output_dev_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + \
                          "_lr" + str(learning_rate) + "_dev.txt"
        output_test_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + "_lr" + str(learning_rate) + "_dev.txt"
        model_test = BertForQuestionAnswering.from_pretrained('/media/sda2/lk/BioBERT/biobert_v1.1_pubmed').to(device)
        model_test.load_state_dict(
            torch.load(save_model_file))
        model_test.eval()
        predicts(model_test, input_file, output_dev_file, dataset="dev1.0.json")
        predicts(model_test, input_file, output_test_file, dataset="test1.0.json")

    if epoch==3:
        save_model_file = file_path + "/model" + "/" + model_name + "_" + data_Classification + "_epochs" + str(
            epoch + 1) + "_lr" + str(learning_rate) + ".pkl"  # 保存模型的地址

        torch.save(model.state_dict(), save_model_file)
        input_file = "/media/sda2/lk/my_model/model_biomrc/sort/Lite_A/"
        output_dev_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + \
                          "_lr" + str(learning_rate) + "_dev.txt"
        output_test_file = file_path + "/results/" + model_name + "_" + data_Classification + "epochs_" + str(
            epoch + 1) + "_lr" + str(learning_rate) + "_dev.txt"
        model_test = BertForQuestionAnswering.from_pretrained('/media/sda2/lk/BioBERT/biobert_v1.1_pubmed').to(device)
        model_test.load_state_dict(
            torch.load(save_model_file))
        model_test.eval()
        predicts(model_test, input_file, output_dev_file, dataset="dev1.0.json")
        predicts(model_test, input_file, output_test_file, dataset="test1.0.json")